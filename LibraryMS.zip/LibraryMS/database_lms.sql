-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2018 at 11:57 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_lms`
--
CREATE DATABASE IF NOT EXISTS `database_lms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `database_lms`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_books`
--

DROP TABLE IF EXISTS `tbl_books`;
CREATE TABLE `tbl_books` (
  `book_id` int(11) NOT NULL,
  `book_title` varchar(250) NOT NULL,
  `book_category` varchar(100) NOT NULL,
  `book_auth` varchar(250) DEFAULT NULL,
  `books_copies` int(11) NOT NULL,
  `book_pub_name` varchar(250) DEFAULT NULL,
  `book_pub_place` varchar(250) DEFAULT NULL,
  `book_isbn` varchar(13) DEFAULT NULL,
  `book_copyright_yr` year(4) NOT NULL,
  `book_date_received` date DEFAULT NULL,
  `book_date_added` date DEFAULT NULL,
  `book_status` enum('NEW','OLD','LOST','DAMAGE','SUBJECT FOR REPLACEMENT','ARCHIVE') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_books`
--

INSERT INTO `tbl_books` (`book_id`, `book_title`, `book_category`, `book_auth`, `books_copies`, `book_pub_name`, `book_pub_place`, `book_isbn`, `book_copyright_yr`, `book_date_received`, `book_date_added`, `book_status`) VALUES
(54, '110 Perc', 'History', 'Tony Consiglio', 35, 'Consiglio Rev', 'USA', '9781891830754', 2018, '2018-02-01', '2018-02-18', 'NEW'),
(58, 'The 120 Days of Simon', 'Economics', 'Peter Park', 56, 'Simon Gardenfors', 'US', '9781603090506', 2018, '2018-02-02', '2018-02-18', 'OLD'),
(67, 'A Matter of Life', 'Science', 'Harold Pett', 67, 'Jeffrey Brown', 'US', '9781603092661', 2018, '2018-02-02', '2018-02-18', 'LOST'),
(68, 'How To Win a Game', 'Science', 'Radny Bros', 10, 'Rad Corp Two', 'China', '9781413461231', 1998, '2018-02-01', '2018-02-06', 'ARCHIVE'),
(69, 'How to Chicken dinner', 'References', 'Chicken Under', 10, 'Chicken booker', 'San Francisco', '0924153461345', 2016, '2018-02-15', '2018-02-18', 'OLD'),
(70, 'Rainbow Six Siege', 'Math', 'Grand Order', 22, 'Grandoer', 'Germany', '0923512341234', 2001, '2018-02-18', '2018-02-18', 'OLD'),
(71, 'DBMS 2', 'Programming', 'Radny', 5, 'Asd', 'Apas', '1312344534123', 2013, '2018-02-20', '2018-02-20', 'OLD');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_borrow`
--

DROP TABLE IF EXISTS `tbl_borrow`;
CREATE TABLE `tbl_borrow` (
  `borrow_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `date_borrow` date NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_borrow`
--

INSERT INTO `tbl_borrow` (`borrow_id`, `member_id`, `date_borrow`, `due_date`) VALUES
(1, 1, '2018-02-01', '2018-02-02'),
(6, 2, '2018-02-19', '2018-02-01'),
(7, 1, '2018-02-19', '2018-02-14'),
(8, 1, '2018-02-19', '2018-02-03'),
(9, 1, '2018-02-19', '2018-02-02'),
(10, 2, '2018-02-19', '2018-02-23'),
(11, 1, '2018-02-19', '2018-02-09'),
(12, 1, '2018-02-19', '2018-02-09'),
(13, 1, '2018-02-19', '2018-02-09'),
(14, 2, '2018-02-19', '2018-02-22'),
(15, 1, '2018-02-19', '2018-02-03'),
(16, 4, '2018-02-19', '2018-02-05'),
(17, 1, '2018-02-19', '2018-02-02'),
(18, 4, '2018-02-20', '2018-02-23'),
(19, 2, '2018-04-10', '2018-04-10'),
(20, 2, '2018-04-10', '2018-04-11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_borrow_details`
--

DROP TABLE IF EXISTS `tbl_borrow_details`;
CREATE TABLE `tbl_borrow_details` (
  `brw_detail_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrow_id` int(11) NOT NULL,
  `borrow_status` enum('LOST','RETURNED','PENDING') NOT NULL,
  `date_returned` date DEFAULT NULL,
  `Lib_trans` varchar(50) NOT NULL,
  `Lib_return` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_borrow_details`
--

INSERT INTO `tbl_borrow_details` (`brw_detail_id`, `book_id`, `borrow_id`, `borrow_status`, `date_returned`, `Lib_trans`, `Lib_return`) VALUES
(1, 54, 1, 'RETURNED', '2018-02-28', 'Radmin', 'Radmin'),
(2, 58, 1, 'RETURNED', '2018-02-03', 'Radmin', 'Radmin'),
(4, 54, 14, 'RETURNED', '2018-02-20', 'Radmin', 'Radmin'),
(5, 67, 14, 'PENDING', '0000-00-00', 'Radmin', 'Radmin'),
(6, 58, 15, 'RETURNED', '2018-04-10', 'Radmin', 'Radmin'),
(7, 69, 15, 'PENDING', '0000-00-00', 'Radmin', 'Radmin'),
(8, 70, 15, 'RETURNED', '2018-02-22', 'Radmin', 'Radmin'),
(9, 54, 16, 'PENDING', '0000-00-00', 'Radmin', 'Radmin'),
(10, 54, 17, 'PENDING', '0000-00-00', 'Radmin', 'Radmin'),
(11, 58, 17, 'PENDING', '0000-00-00', 'Radmin', 'Radmin'),
(12, 69, 18, 'RETURNED', '2018-04-10', 'Radmin', 'Radmin'),
(13, 70, 18, 'RETURNED', '2018-02-20', 'Radmin', 'Radmin'),
(14, 71, 19, 'RETURNED', '2018-04-10', 'Radmin', 'Radmin'),
(15, 71, 20, 'RETURNED', '2018-04-10', 'singer', 'vincent');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE `tbl_category` (
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_name`) VALUES
('Economics'),
('Encyclopedia'),
('English'),
('Filipiniana'),
('General'),
('History'),
('Math'),
('Music'),
('Newspaper'),
('Periodical'),
('Programming'),
('References'),
('Science');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lost_book`
--

DROP TABLE IF EXISTS `tbl_lost_book`;
CREATE TABLE `tbl_lost_book` (
  `book_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `date_lost` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_members`
--

DROP TABLE IF EXISTS `tbl_members`;
CREATE TABLE `tbl_members` (
  `members_id` int(11) NOT NULL,
  `mem_firstname` varchar(100) NOT NULL,
  `mem_lastname` varchar(100) NOT NULL,
  `mem_gender` enum('Female','Male') NOT NULL,
  `mem_address` varchar(100) NOT NULL,
  `mem_contact` varchar(100) DEFAULT NULL,
  `mem_type` varchar(100) NOT NULL,
  `mem_status` enum('ACTIVE','BANNED') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_members`
--

INSERT INTO `tbl_members` (`members_id`, `mem_firstname`, `mem_lastname`, `mem_gender`, `mem_address`, `mem_contact`, `mem_type`, `mem_status`) VALUES
(1, 'Joseph Radny', 'Ongtawco', 'Male', 'Consolacion, Cebu', '09211255277', 'Teacher', 'ACTIVE'),
(2, 'Aruna', 'Ender', 'Female', 'USA', '09231551411', 'Teacher', 'ACTIVE'),
(3, 'Ryan', 'Exley', 'Female', 'China', '09844421122', 'Student', 'BANNED'),
(4, 'Vincent NiÃ±o', 'Apas', 'Male', 'Liloan', '098127621', 'Student', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type`
--

DROP TABLE IF EXISTS `tbl_type`;
CREATE TABLE `tbl_type` (
  `borrower_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_type`
--

INSERT INTO `tbl_type` (`borrower_type`) VALUES
('Construction'),
('Employee'),
('Non-Teaching'),
('Student'),
('Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fullname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `fullname`) VALUES
(1, 'Radmin', 'Radmin', 'Joseph Radny Y. Ongtawco'),
(2, 'sawano1', 'qwerty', 'Hiroyuki Sawano'),
(3, 'wolfy123', 'woof', 'WOLFE'),
(4, 'singer', 'singer123', 'Aimer Ninelie'),
(5, 'vincent', 'vincent', 'Vincent Nino Apas'),
(6, 'beater', 'beater', 'The SchizoFreniks'),
(7, 'beep boop', 'retro boom', 'Crazy Daylight'),
(8, 'asd', '123', 'Vincent Nino Apas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `book_category` (`book_category`);

--
-- Indexes for table `tbl_borrow`
--
ALTER TABLE `tbl_borrow`
  ADD PRIMARY KEY (`borrow_id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexes for table `tbl_borrow_details`
--
ALTER TABLE `tbl_borrow_details`
  ADD PRIMARY KEY (`brw_detail_id`),
  ADD KEY `borrow_id` (`borrow_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_name`);

--
-- Indexes for table `tbl_lost_book`
--
ALTER TABLE `tbl_lost_book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `tbl_members`
--
ALTER TABLE `tbl_members`
  ADD PRIMARY KEY (`members_id`);

--
-- Indexes for table `tbl_type`
--
ALTER TABLE `tbl_type`
  ADD PRIMARY KEY (`borrower_type`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_books`
--
ALTER TABLE `tbl_books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `tbl_borrow`
--
ALTER TABLE `tbl_borrow`
  MODIFY `borrow_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `tbl_borrow_details`
--
ALTER TABLE `tbl_borrow_details`
  MODIFY `brw_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_members`
--
ALTER TABLE `tbl_members`
  MODIFY `members_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD CONSTRAINT `tbl_books_ibfk_1` FOREIGN KEY (`book_category`) REFERENCES `tbl_category` (`category_name`);

--
-- Constraints for table `tbl_borrow`
--
ALTER TABLE `tbl_borrow`
  ADD CONSTRAINT `tbl_borrow_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `tbl_members` (`members_id`);

--
-- Constraints for table `tbl_borrow_details`
--
ALTER TABLE `tbl_borrow_details`
  ADD CONSTRAINT `tbl_borrow_details_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `tbl_books` (`book_id`),
  ADD CONSTRAINT `tbl_borrow_details_ibfk_2` FOREIGN KEY (`borrow_id`) REFERENCES `tbl_borrow` (`borrow_id`);

--
-- Constraints for table `tbl_lost_book`
--
ALTER TABLE `tbl_lost_book`
  ADD CONSTRAINT `tbl_lost_book_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `tbl_books` (`book_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
