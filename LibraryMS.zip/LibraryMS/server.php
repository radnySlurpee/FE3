<?php
    include 'locker.php';
    if (!isset($_SESSION['username'])){
    header("refresh:3; url=index.php");
}

include 'designs.php';

$GLOBALS['hdr'] = "refresh:3; url=index.php";
$GLOBALS['last_ID'] ='0';
//initiator
if (isset($_POST['add_user'])) {
    insertUser();
}
if (isset($_POST['upd_user'])){
    updateUser();
}
if (isset($_POST['add_mem'])){
    insertMember();
}
if (isset($_POST['upd_mem'])){
    updateMember();
}
if (isset($_POST['add_bok'])){
    insertBook();
}
if (isset($_POST['upd_book'])){
    updateBook();
}
if (isset($_POST['add_borrow'])){
    insertBorrow();
    insertBorrowDetails($last_ID);
}
if (isset($_POST['retbook'])){
    updateBorrowDetails();
}
//after process
   $msg = "<br> SYSTEM PROCESS IS HIDDEN <br> <br> ".$imgSkull;
   header($hdr);

?>

<?php
function insertUser(){

    $paramList = array();
    $paramList[] = $_POST['user'];
    $paramList[] = $_POST['pass'];
    $paramList[] = $_POST['name'];

    execQuery($paramList, 
    'INSERT INTO `tbl_users`(`username`, `password`, `fullname`) VALUES (?,?,?)',
    "Location:users.php");
}

function updateUser(){

    $paramList = array();
    $paramList[] = $_POST['user'];
    $paramList[] = $_POST['pass'];
    $paramList[] = $_POST['name'];
    $paramList[] = $_POST['userID'];

    execQuery($paramList, 
    'UPDATE `tbl_users` SET `username`=?,`password`=?,`fullname`=? WHERE `user_id`=?',
    "Location:users.php");
}

function insertMember(){

    $paramList = array();
    $paramList[] = $_POST['fs'];
    $paramList[] = $_POST['ls'];
    $paramList[] = $_POST['gen'];
    $paramList[] = $_POST['adr'];
    $paramList[] = $_POST['con'];
    $paramList[] = $_POST['typ'];
    $paramList[] = $_POST['sts'];

    execQuery($paramList, 
    'INSERT INTO `tbl_members`(`mem_firstname`, `mem_lastname`, `mem_gender`, `mem_address`, `mem_contact`, `mem_type`, `mem_status`) VALUES (?,?,?,?,?,?,?)',
    "Location:member.php");
}

function updateMember(){

    $paramList = array();
    $paramList[] = $_POST['fs'];
    $paramList[] = $_POST['ls'];
    $paramList[] = $_POST['gen'];
    $paramList[] = $_POST['adr'];
    $paramList[] = $_POST['con'];
    $paramList[] = $_POST['typ'];
    $paramList[] = $_POST['sts'];
    $paramList[] = $_POST['memID'];

    execQuery($paramList, 
    'UPDATE `tbl_members` SET `mem_firstname`=?,`mem_lastname`=?,`mem_gender`=?,`mem_address`=?,`mem_contact`=?,`mem_type`=?,`mem_status`=? WHERE `members_id`=?',
    "Location:member.php");
}


function insertBook(){

    $paramList = array();
    $paramList[] = $_POST['title'];
    $paramList[] = $_POST['cat'];
    $paramList[] = $_POST['auth'];
    $paramList[] = $_POST['qty'];
    $paramList[] = $_POST['pubName'];
    $paramList[] = $_POST['pubAddr'];
    $paramList[] = $_POST['ISBN'];
    $paramList[] = $_POST['copyr'];
    $paramList[] = $_POST['stats'];


    execQuery($paramList, 
    'INSERT INTO `tbl_books`(`book_title`, `book_category`, `book_auth`, `books_copies`, `book_pub_name`, `book_pub_place`, `book_isbn`, `book_copyright_yr`, `book_date_received`, `book_date_added`, `book_status`) VALUES (?,?,?,?,?,?,?,?,CURDATE(),CURDATE(),?)',
    "Location:books.php");
}


function updateBook(){

    $paramList = array();
    $paramList[] = $_POST['title'];
    $paramList[] = $_POST['cat'];
    $paramList[] = $_POST['auth'];
    $paramList[] = $_POST['qty'];
    $paramList[] = $_POST['pubName'];
    $paramList[] = $_POST['pubAddr'];
    $paramList[] = $_POST['ISBN'];
    $paramList[] = $_POST['copyr'];
    $paramList[] = $_POST['stats'];
    $paramList[] = $_POST['bookID'];

    execQuery($paramList, 
    'UPDATE `tbl_books` SET `book_title`=?,`book_category`=?,`book_auth`=?,`books_copies`=?,`book_pub_name`=?,`book_pub_place`=?,`book_isbn`=?,`book_copyright_yr`=?,`book_date_added`= CURDATE(),`book_status`=? WHERE `book_id`=?',"Location:books.php");
}


function insertBorrow(){

    $paramList = array();
    $paramList[] = $_POST['mem'];
    $paramList[] = $_POST['due'];

    execQuery($paramList, 
    'INSERT INTO `tbl_borrow`(`member_id`, `date_borrow`, `due_date`) VALUES (?,CURDATE(),?)',"");
        

}
function insertBorrowDetails($lastID){

    if(!empty($_POST["book"]))
    {
        foreach($_POST["book"] as $book)
        {
            
            $paramList = array();
            $paramList[] = $book;
            $paramList[] = $lastID;
            $paramList[] = "PENDING";
            $paramList[] = "NULL";
            $paramList[] = $_SESSION['username'];

            execQuery($paramList, 
            'INSERT INTO `tbl_borrow_details`(`book_id`, `borrow_id`, `borrow_status`, `date_returned`,`Lib_trans`) VALUES (?,?,?,?,?)',"Location:transaction.php");
            
        }

    }

}

function updateBorrowDetails(){

    $paramList = array();
    $paramList[] = "RETURNED";
    $paramList[] = $_SESSION['username'];
    $paramList[] = $_POST['retbook'];

    execQuery($paramList, 
    'UPDATE `tbl_borrow_details` SET `borrow_status`=?,`Lib_return`=?,`date_returned`= CURDATE() WHERE `brw_detail_id`=?',"Location:transaction.php");
        
}
//Function For Query

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// $stmt = The SQL Statement Object
// $param = Array of the Parameters
function AddParams($stmt, $params)
{
    if ($params != null)
    {
        // Generate the Type String (eg: 'issisd')
        $types = '';
        foreach($params as $param)
        {
            if(is_int($param)) {
                // Integer
                $types .= 'i';
            } elseif (is_float($param)) {
                // Double
                $types .= 'd';
            } elseif (is_string($param)) {
                // String
                $types .= 's';
            } else {
                // Blob and Unknown
                $types .= 'b';
            }
        }
  
        // Add the Type String as the first Parameter
        $bind_names[] = $types;
  
        // Loop thru the given Parameters
        for ($i=0; $i<count($params);$i++)
        {
            // Create a variable Name
            $bind_name = 'bind' . $i;
            // Add the Parameter to the variable Variable
            $$bind_name = $params[$i];
            // Associate the Variable as an Element in the Array
            $bind_names[] = &$$bind_name;
        }
         
        // Call the Function bind_param with dynamic Parameters
        call_user_func_array(array($stmt,'bind_param'), $bind_names);
    }
    return $stmt;
}

function execQuery($paramList,$query,$hdr){
    include "connection.php";
    $stmt = $conn->prepare($query);
    AddParams($stmt, $paramList);
    $stmt->execute();
    $GLOBALS['last_ID'] = $stmt->insert_id;
    $stmt->close(); 
    $conn->close();
    
    if ($hdr!="") {
        $GLOBALS['hdr'] = "$hdr";
    }
   
}

 ?>

 <!DOCTYPE html>
 <html>
<head>
    <title>Library Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="main.css">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="https://fonts.googleapis.com/css?family=Share+Tech+Mono" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-food.css">
</head>
 <body style="background-image: url(Images/bg_web.jpg);">
    <h1 class="<?php echo $headerDGA ?> w3-center"><?php echo $msg ?></h1>
 </body>
 </html> 


