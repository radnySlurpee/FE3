<?php include 'header.php'; ?>
<div class="<?php echo $containerTabDGA ?>">
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="" name="">
	<button class="w3-bar-item w3-button w3-hover-dark-gray w3-right"> <?php echo $imgView ?> FIND </button>
</div>

<div class="">
		<h4 class="<?php echo $headerDGA ?>"> ARCHIVE TABLE </h4>
		<p><table class="<?php echo $table ?>" >
		  <tr class="w3-aqua w3-text-black">
		      <th>Book</th>
		      <th>Information </th>
		      <th>Date</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_books` WHERE book_status ='ARCHIVE'";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td><label class="w3-medium">
		      	  <i>ISBN: </i><?php echo $row['book_isbn'] ?><br>
		      	  <i>Title: </i><?php echo $row['book_title'] ?><br>
		      	  <i>Category: </i><?php echo $row['book_category'] ?><br>
		      	  
		      	</label>
		      </td>
		      <td><label class="w3-medium">
		      	  <i>Author: </i><?php echo $row['book_auth'] ?><br>
		      	  <i>Publisher: </i><?php echo $row['book_pub_name']." ,".$row['book_pub_place']?><br>
		      	  <i>Copyright: </i><?php echo $row['book_copyright_yr'] ?><br>
				  <i>QTY: </i><?php echo $row['books_copies'] ?><br>
		      	</label></td>

			      	 <td><label class="w3-medium">
				      	  <i>REC: </i><?php echo $row['book_date_received'] ?>
				      	  <br><i> ADD: </i><?php echo $row['book_date_added'] ?>
			      	 </td></label>		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
</div>

</div>
</body>
</html>