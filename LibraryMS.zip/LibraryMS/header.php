<?php 
  include 'locker.php';
?>
<?php include 'designs.php'; ?>
<?php include 'connection.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Library Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="main.css">
<link rel="shortcut icon" href="Images/books.png" />
<link rel="stylesheet" href="inputDesign.css">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="https://fonts.googleapis.com/css?family=Share+Tech+Mono" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-food.css">
</head>
<body style="background-image: url(Images/bg_web.jpg);" class="w3-animate-top">

	<div class="w3-bar w3-left-align w3-top w3-text-aqua" style="background-image: url(Images/bg_web.jpg);">
		    <a class="w3-bar-item w3-button w3-left w3-hide-large w3-hover-pink w3-large" href="javascript:void(0)" onclick="w3_open()"><img src="Images/menu.png" width="24px"></a>
		<a href="index.php" class="<?php echo $navHeader ?>"><?php echo $imgHome ?> HOME </a>
		<a href="users.php" class="<?php echo $navHeader ?>"><?php echo $imgUser ?> USERS </a>
		<a href="transaction.php" class="<?php echo $navHeader ?>"><?php echo $imgTrans ?> TRANSACTION </a>
		<a href="books.php" class="<?php echo $navHeader ?>"><?php echo $imgBooks ?> BOOKS </a>
		<a href="member.php" class="<?php echo $navHeader ?>"><?php echo $imgMem ?> MEMBERS </a>
		<a href="archive.php" class="<?php echo $navHeader ?>"><?php echo $imgArc ?> ARCHIVE </a>
    <a href="advanceSearch.php" class="<?php echo $navHeader ?>"><?php echo $imgView ?> ADVANCE SEARCH </a>
		<a href="reports.php" class="<?php echo $navHeader ?>"><?php echo $imgReps ?> REPORTS </a>
		<form action="logout.php" method="post">
    <button name="logout" type="submit" class="<?php echo $navHeader ?>"><?php echo $imgLout ?> LOGOUT </button></form>
	  <label class="w3-right w3-spin w3-hide-small"> <img src="images/sphere.png" style="width: 40px"></label>
	</div><br>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer;" title="close side menu" id="myOverlay">
	<!-- Sidebar -->
<nav class="w3-sidebar w3-bar-block w3-collapse w3-large w3-animate-left w3-black" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-right w3-xlarge w3-padding-large w3-hover-pink w3-hide-large" title="Close Menu"><img src="Images/close.png" width="24px">
  </a>  <h4 class="w3-bar-item"><label class="w3-aqua w3-text-black">[ MENU ]</label></h4>

		<a href="index.php" class="<?php echo $navHeader2 ?>"><?php echo $imgHome ?> HOME </a>
		<a href="users.php" class="<?php echo $navHeader2 ?>"><?php echo $imgUser ?> USERS </a>
		<a href="transaction.php" class="<?php echo $navHeader2 ?>"><?php echo $imgTrans ?> TRANSACTION </a>
		<a href="books.php" class="<?php echo $navHeader2 ?>"><?php echo $imgBooks ?> BOOKS </a>
		<a href="member.php" class="<?php echo $navHeader2 ?>"><?php echo $imgMem ?> MEMBERS </a>
		<a href="archive.php" class="<?php echo $navHeader2 ?>"><?php echo $imgArc ?> ARCHIVE </a>
		<a href="reports.php" class="<?php echo $navHeader2 ?>"><?php echo $imgReps ?> REPORTS </a>
    <a href="advanceSearch.php" class="<?php echo $navHeader2 ?>"><?php echo $imgReps ?> ADVANCE SEARCH </a>
	 <form action="logout.php" method="post">
    <button name="logout" type="submit" class="<?php echo $navHeader ?>"><?php echo $imgLout ?> LOGOUT </button></form>
    <label class="w3-right w3-spin w3-hide-small"> <img src="images/sphere.png" style="width: 40px"></label>
</nav>

</div>

<div class="w3-container w3-margin w3-animate-top">

<script type="text/javascript">

function openCity(cityName)
{
    var i;
    var x = document.getElementsByClassName("tab");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}
</script>

<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}
</script>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
    if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
    } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
    }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
    overlayBg.style.display = "none";
}
</script>

<script>
function searcher() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("inputSearch");
  filter = input.value.toUpperCase();
  table = document.getElementById("outputSearch");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

<script>
function searcher1() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("inputSearch1");
  filter = input.value.toUpperCase();
  table = document.getElementById("outputSearch1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

<script>
function searcher2() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("inputSearch2");
  filter = input.value.toUpperCase();
  table = document.getElementById("outputSearch2");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

<script>
function searcher3() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("inputSearch3");
  filter = input.value.toUpperCase();
  table = document.getElementById("outputSearch3");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>