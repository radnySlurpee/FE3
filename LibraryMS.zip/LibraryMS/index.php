
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<br><br>
<h4 class="<?php echo $headerDGA ?>">HELLO : <label class="w3-aqua w3-border w3-border-aqua"><?php echo $_SESSION['username']; ?></label></h4>
	<br>
<h1 class="<?php echo $headerDGA ?>"> <img src="Images/libraryISO.png" width="300px"> </h1>
<br>
<p><h1 class="<?php echo $headerDGA ?>"> LIBRARY MANAGEMENT SYSTEM </h1></p>
<hr class="w3-border w3-border-aqua">
<br><br>
<p><h2 class="<?php echo $headerDGA ?>"> DASHBOARD </h2></p>
<div style="overflow: auto;max-width: 100%;max-height: 700px">
<table class="<?php echo $table ?>" style = "width: 1500px">
		  
		  <tr class="w3-aqua w3-text-black">
		  	  <th>Status</th>
		      <th>Book</th>
		      <th>Member</th>
		      <th>Librarian in <br>Transaction</th>
		      <th>Librarian in <br>Received</th>
		      <th>Date of<br>Return</th>
		      <th>Date of<br>Due</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_borrow_details`,`tbl_books`,`tbl_members`,`tbl_borrow` WHERE tbl_borrow_details.book_id = tbl_books.book_id AND tbl_borrow_details.borrow_id = tbl_borrow.borrow_id AND tbl_borrow.member_id = tbl_members.members_id
	      		ORDER BY brw_detail_id DESC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		   	   <td><?php $date1 = date_create($row['date_returned']);
					$date2 = date_create($row['due_date']);
					$diff = date_diff($date1,$date2);
					//echo $diff->format("%R%a days");
					if ($diff->format("%R") == "-") { echo "<label class='w3-amber w3-wide'> OVERDUE </label>"; }
					elseif ($row['borrow_status']=="PENDING") { echo "<label class='w3-blue w3-wide w3-text-black'> PENDING </label>"; }
					else{ echo "<label class='w3-aqua w3-wide w3-text-black'> RETURN </label>"; }?></td>
		      <td><?php echo $row['book_title'] ?> </td>
			  <td><?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?></td>
		      <td><?php echo $row['Lib_trans'] ?></td>
		      <td><?php echo $row['Lib_return'] ?></td>
  		      <td><?php echo $row['date_returned'] ?></td>
			  <td><?php echo $row['due_date'] ?></td>	    	 
		    </tr>
		    	
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table>
</div>
		
</body>
</html>