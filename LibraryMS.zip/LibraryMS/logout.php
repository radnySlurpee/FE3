<?php
	session_start();
	if (isset($_POST["logout"])) {
		session_destroy();
	}
	header("refresh:0; url=login.php");
?>