<?php 

//OOP concept
$buttonDG = "w3-button w3-text-aqua w3-wide w3-round w3-hover-pink w3-hover-text-black w3-animate-zoom w3-border w3-border-aqua";
$buttonDGA = "w3-button w3-text-aqua w3-wide w3-round-xlarge w3-hover-teal w3-hover-text-black w3-animate-zoom  w3-border w3-border-aqua";
$inputBC ="w3-input w3-border w3-border-aqua w3-black w3-text-aqua w3-round w3-animate-zoom"; 
$SelectBC ="w3-select w3-border w3-border-aqua w3-black w3-text-aqua w3-round w3-animate-zoom"; 
$containerLG = "w3-container w3-padding-small w3-animate-zoom";
$containerDGA = "w3-text-aqua w3-wide w3-padding w3-animate-zoom";
$containerTabDGA = "w3-bar w3-text-aqua w3-round-large w3-animate-zoom w3-padding-16";
$searchContainer = "w3-text-aqua w3-wide w3-padding w3-animate-zoom w3-round-xxlarge";
$headerDGA = "w3-text-aqua w3-wide w3-padding-small w3-center";
$table = "w3-table w3-border w3-border-aqua w3-text-aqua";
$navbar1="w3-bar-item w3-button w3-hover-pink w3-hover-text-black w3-border w3-border-aqua";
$navHeader="w3-bar-item w3-button w3-hover-pink w3-hover-text-black w3-hide-small";
$navHeader2="w3-bar-item w3-button w3-hover-pink w3-hover-text-black w3-small w3-black w3-text-aqua";
$modSpan = "w3-button w3-display-topright w3-text-cyan w3-hover-pink w3-hover-text-black";

//images
$imgPass = '<img src="Images/pass.png" width="44px">';
$imgHome = '<img src="Images/home.png" width="24px">';
$imgReps = '<img src="Images/reps.png" width="24px">';
$imgUser = '<img src="Images/user.png" width="24px">';
$imgTrans = '<img src="Images/transaction.png" width="24px">';
$imgBooks = '<img src="Images/books.png" width="24px">';
$imgMem = '<img src="Images/member.png" width="24px">';
$imgArc = '<img src="Images/archive.png" width="24px">';
$imgLout = '<img src="Images/logout.png" width="24px">';
$imgView = '<img src="images/view.png" width="24">';
$imgEdit = '<img src="images/edit.png" width="24">';
$imgReturn = '<img src="images/returnbook.png" width="26">';
$imgCancel = '<img src="images/close.png" width="26">';
$imgSkull = '<img src="images/skull.png" width="100">';


?>
