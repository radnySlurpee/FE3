<?php include 'header.php'; ?>


<?php if (isset($_POST['editUser'])): ?><!-- Modal for User  -->
<?php $userID = $_POST['editUser'];
$sql = "SELECT * FROM `tbl_users` WHERE user_id = '$userID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>
	      		       
    <p><div class="w3-modal-content w3-animate-zoom w3-black w3-text-aqua"> 
        <a href="users.php" class="<?php echo $modSpan ?>">&times;</a>
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgEdit ?> Update User Account </h2>
		  </div>
	  <form class="w3-container" action="server.php" method="post">
	    <div class="w3-row-padding">
	    	<input type="hidden" name="userID" value="<?php echo $row['user_id'] ?>">
	    	<p><label> Fullname </label>
  			<input value="<?php echo $row['fullname'] ?>" class="<?php echo $inputBC ?>" name="name" type="text" required></p>
	  		<p><label> Username </label>
  			<input value="<?php echo $row['username'] ?>" class="<?php echo $inputBC ?>" name="user" type="text" required></p>
	  		<p><label> Password </label>
  			<input value="<?php echo $row['password'] ?>" class="<?php echo $inputBC ?>" name="pass" type="text" required></p>
		</div>
		    <p class="w3-center">
		    <button type="submit" name="upd_user" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
	  </form>
    </div></p>
<?php endwhile ?><?php endif ?>
<?php endif ?><!-- Modal for User  -->
<!-- Modal BOUNDARY  #############################################################################################-->
<?php if (isset($_POST['updmem'])): ?>	<!-- Modal for member  -->

<?php $memID = $_POST['updmem'];
$sql = "SELECT * FROM `tbl_members` WHERE members_id = '$memID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>

    <p><div class="w3-modal-content w3-animate-zoom w3-card-4 w3-black w3-text-aqua"> 
        <a href="member.php" class="<?php echo $modSpan ?>">&times;</a>		  
		  <div class="w3-container w3-wide">
		    <h2>  <?php echo $imgEdit ?> Update Member </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="mem_form">
	            <input type="hidden" name="memID" value="<?php echo $row['members_id'] ?>">
		    <div class="w3-row-padding">
		    	<p><label> first name </label>
		  			<input class="<?php echo $inputBC ?>" name="fs" value="<?php echo $row['mem_firstname'] ?>" type="text" required></p>
		  		<p><label> last name </label>
		  			<input class="<?php echo $inputBC ?>" name="ls" value="<?php echo $row['mem_lastname'] ?>" type="text" required></p>
		  		<p><label> Address </label>
		  			<input class="<?php echo $inputBC ?>" name="adr" value="<?php echo $row['mem_address'] ?>" type="text" required></p>
		  		<p><label> Contact </label>
		  			<input class="<?php echo $inputBC ?>" name="con" value="<?php echo $row['mem_contact'] ?>" type="text" required></p>
		  		<p><label> Gender </label>
		  			<select class="<?php echo $inputBC ?>" name="gen" form="mem_form" required>
					  <option value="<?php echo $row['mem_gender'] ?>" selected><?php echo $row['mem_gender'] ?></option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select></p>

		  		<p><label> Status </label>
		  			<select class="<?php echo $inputBC ?>" name="sts" form="mem_form" required>
					  <option value="<?php echo $row['mem_status'] ?>" selected><?php echo $row['mem_status'] ?></option>
						<option value="ACTIVE">ACTIVE</option>
						<option value="BANNED">BANNED</option>
					</select></p>

		  		<p><label> Type </label>
		  			<select class="<?php echo $inputBC ?>" name="typ" form="mem_form" required>
					  <option value="<?php echo $row['mem_type'] ?>" selected><?php echo $row['mem_type'] ?></option>
<?php
$sql2 = "SELECT * FROM `tbl_type`";
$result2 = $conn->query($sql2);
if ($result2->num_rows > 0): ?>
<?php while ($row = $result2->fetch_assoc()): ?>
					  <option value="<?php echo $row['borrower_type'] ?>"> <?php echo $row['borrower_type'] ?> </option>
	<?php endwhile ?>		      	
<?php endif ?></select></p>
	
			</div>

		    <p class="w3-center">
		    <button type="submit" name="upd_mem" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
		  </form>
    </div></p>
<!-- Modal for member  -->
<?php endwhile ?><?php endif ?>

<?php endif ?>



<?php if (isset($_POST['upd_bok'])): ?>
	
<!-- Modal for book  -->
<?php $bookID = $_POST['upd_bok'];
$sql = "SELECT * FROM `tbl_books` WHERE book_id = '$bookID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>
 
    <p><div class="w3-modal-content w3-animate-zoom w3-card-4 w3-black w3-text-aqua"> 
        <a href="books.php" class="<?php echo $modSpan ?>">&times;</a>		  
		  <div class="w3-container w3-wide">
		    <h2>  <?php echo $imgEdit ?> Update Book </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="book_form">
		       <input type="hidden" name="bookID" value="<?php echo $row['book_id'] ?>">
	    <div class="w3-row-padding">
	    	<p><label> Book Title </label>
	  			<input value="<?php echo $row['book_title'] ?>" class="<?php echo $inputBC ?>" name="title" type="text" required></p>
	  		<p><label> Category </label>
	  			<select class="<?php echo $inputBC ?>" name="cat" form="book_form" required>
				  <option value="<?php echo $row['book_category'] ?>" selected><?php echo $row['book_category'] ?></option>
<?php
$sql1 = "SELECT * FROM `tbl_category`";
$result1 = $conn->query($sql1);
if ($result1->num_rows > 0): ?>
<?php while ($row1 = $result1->fetch_assoc()): ?>
				  <option value="<?php echo $row1['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
<?php endwhile ?><?php endif ?>
		      	

				</select></p>
	  		<p><label> Author </label>
	  			<input value="<?php echo $row['book_auth'] ?>" class="<?php echo $inputBC ?>" name="auth" type="text"></p>
	  		<p><label> Book Copies </label>
	  			<input value="<?php echo $row['books_copies'] ?>" class="<?php echo $inputBC ?>" name="qty" type="number"></p>
	  		<p><label> Book Publication </label>
	  			<input value="<?php echo $row['book_pub_place'] ?>" class="<?php echo $inputBC ?>" name="pubAddr" type="text" required></p>
	  		<p><label> Publisher Name </label>
	  			<input value="<?php echo $row['book_pub_name'] ?>" class="<?php echo $inputBC ?>" name="pubName" type="text" required></p>
	  		<p><label> ISBN </label>
	  			<input value="<?php echo $row['book_isbn'] ?>" class="<?php echo $inputBC ?>" name="ISBN" type="number"></p>
	  		<p><label> Copyright Year </label>
	  			<input value="<?php echo $row['book_copyright_yr'] ?>" class="<?php echo $inputBC ?>" name="copyr" type="number" required></p>
  			<p><label> Status </label>
			    <select class="<?php echo $inputBC ?>" name="stats" form="book_form" required>
				  <option value="<?php echo $row['book_status'] ?>" selected><?php echo $row['book_status'] ?></option>
				  <option value="NEW"> NEW </option>
				  <option value="OLD"> OLD </option>
				  <option value="LOST"> LOST </option>
				  <option value="DAMAGE"> DAMAGE </option>
				  <option value="ARCHIVE"> ARCHIVE </option>
				  <option value="SUBJECT FOR REPLACEMENT">SUBJECT FOR REPLACEMENT</option>
				</select></p>
			</div>


		    <p class="w3-center">
		    <button name="upd_book" type="submit" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
		  </form>
    </div>
  </div></p>
<?php endwhile ?><?php endif ?> 
<!-- Modal for book  -->
<?php endif ?>


<?php if (isset($_POST['borrow_book'])): ?>
<!-- Modal for borrowing  -->	
<div class="w3-modal-content w3-animate-zoom w3-black w3-text-aqua"> 
         <a href="transaction.php" class="<?php echo $modSpan ?>">&times;</a>	  
		  <div class="w3-container w3-wide">
		    <h2> Borrow Transaction </h2>
		  </div>
	    <form class="w3-container" action="server.php" method="post" id="book_form">  	
		   <p><label class="w3-text-aqua"> Member </label>
		  			<select class="<?php echo $SelectBC ?>" name="mem" form="book_form" required>
					  <option value="" disabled selected>Choose..</option>
						<?php
						$sql = "SELECT * FROM `tbl_members` WHERE mem_status = 'ACTIVE'";
						$result = $conn->query($sql);
						if ($result->num_rows > 0): ?>
						<?php while ($row = $result->fetch_assoc()): ?>
					  <option value="<?php echo $row['members_id'] ?>"> <?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?> </option>
							<?php endwhile ?><?php endif ?>		      	
						</select></p>

				<p><label class="w3-text-aqua"> Due date </label>
				<input class="<?php echo $inputBC ?>" name="due" type="date" required></p>
<?php if (isset($_POST["borrow_book"])): ?>

	<p><table class="<?php echo $table ?>" >
		<label class="w3-left w3-aqua w3-text-black w3-small">[ List of Books to be borrowed ]</label>
		  <tr class="w3-text-black w3-aqua w3-small">
		      <th>ISBN</th>
		      <th>Title</th>
		      <th>Author</th>
	      </tr>


	<?php if (!empty($_POST["bok"])): ?>
		<?php foreach ($_POST["bok"] as $bok): ?>


<?php
$sql = "SELECT * FROM `tbl_books` WHERE book_id ='$bok'";
$result = $conn->query($sql);
if ($result->num_rows > 0): ?>
<?php while ($row = $result->fetch_assoc()): ?>
<tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
	<td>
		<input type="hidden" name="book[]" value="<?php echo $bok ?>">
  		<?php echo $row['book_isbn'] ?>
	</td>
	<td>
  		<?php echo $row['book_title'] ?>
	</td>
	<td>
		<?php echo $row['book_auth'] ?>
	</td> 
</tr>					      			
<?php endwhile ?>		      	
<?php endif ?>

			<?php endforeach ?>
				</table></p>
				<p class="w3-center">
  			  	<button name="add_borrow" type="submit" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
  		<?php else: ?>
  			</table></p>
  			<p class="w3-panel w3-small w3-center">	PLEASE SELECT AT LEAST ONE BOOK TO BORROW </p>
		<?php endif ?>

	<?php endif ?>

  	</form>
	    </div>
	
<!-- Modal for borrowing  -->
<?php endif ?>
<!-- Modal for confirmation upon return  -->
<?php if (isset($_POST["temp_retbook"])): ?>
	<br><br>
<div class="w3-black w3-border w3-border-aqua w3-padding w3-text-aqua w3-margin w3-center">
		<br>
		<h3>
			Do you want to Return the book <label class="w3-text-pink"> <?php echo $_POST['name_book'] ?> </label>
			from the borrower <label class="w3-text-amber"> <?php echo $_POST['name_borrower'] ?> </label> ?
		</h3>
		<hr class="w3-border w3-border-aqua">

	<p><form method="post" action="server.php">
	 	<button type="submit" value="<?php echo $_POST["temp_retbook"] ?>" name="retbook" class="<?php echo $buttonDGA; ?>">
	 	<?php echo $imgReturn ?> YES  </button>
	 	<a href="transaction.php" class="<?php echo $buttonDGA; ?>">
	 	<?php echo $imgCancel ?> NO </a>
 	</form></p>	

<br>
</div>
<?php endif ?>


</div>
</body>
</html>