<?php include 'header.php'; ?>


<div class="<?php echo $containerTabDGA ?>">
<label class="w3-left w3-aqua w3-text-black w3-small">[ Select Transaction ]</label>
<br>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('borrow')">BORROW</button>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('returned')">VIEW RETURNED BOOKS</button>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('borrowed')">VIEW BORROWED BOOKS</button>
</div>

<div id="borrow" class="<?php echo $containerLG ?> tab">

<form method="post" action="update_mod.php">
<div class="<?php echo $containerTabDGA ?>">
	<button type="submit" name="borrow_book" class="<?php echo $buttonDG; ?>"> <img src="images/add.png" width="22px" title="Please select at least one book" > Borrow </button>
	<p class="w3-panel w3-black w3-text-aqua w3-padding" > <-  Please select at least one Book to borrow</p>

	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="searcher" id="inputSearch3" onkeyup="searcher3()">
	<button class="w3-bar-item w3-button w3-hover-black w3-right"> <?php echo $imgView ?> FIND </button>
</div>	

	<div class="">
		<p><h4 class="<?php echo $headerDGA ?>"> BORROW TRANSACTION </h4></p>
		<p><table class="<?php echo $table ?>" id="outputSearch3">
		  <tr class="w3-text-black w3-aqua">
		      <th>Book</th>
		      <th>Details </th>
		      <th>Selection</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_books` WHERE book_status !='ARCHIVE'";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td><label class="w3-medium">
		      	  <i>ISBN: </i><?php echo $row['book_isbn'] ?><br>
		      	  <i>Title: </i><?php echo $row['book_title'] ?>
		      	</label>
		      </td>
		      <td><label class="w3-medium">
		      	  <i>Author: </i><?php echo $row['book_auth'] ?><br>
		      	  <i>Publisher: </i><?php echo $row['book_pub_name']." ,".$row['book_pub_place']?>
		      	</label></td>

			      	 <td>
				   		
							<label class="container">
							 <input type="checkbox" value="<?php echo $row['book_id'] ?>" name="bok[]"></input>
							 <span class="checkmark"></span>
							</label>
							<p>
				       
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>


 				</form>
		 </table></p>
	</div>

</div>
<div id="returned" class="<?php echo $containerLG ?> tab" style="display:none">

<div class="<?php echo $containerTabDGA ?>">
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="searcher" id="inputSearch1" onkeyup="searcher1()">
	<button class="w3-bar-item w3-button w3-hover-black w3-right"> <?php echo $imgView ?> FIND </button>
</div>	
	
		<h4 class="<?php echo $headerDGA ?>"> RETURNED BOOKS TABLE </h4>
		<p><table class="<?php echo $table ?>" id="outputSearch1" >
		  <tr class="w3-aqua w3-text-black">
		      <th>Book</th>
		      <th>Member</th>
		      <th>DATE OF</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_borrow_details`,`tbl_books`,`tbl_members`,`tbl_borrow` WHERE tbl_borrow_details.book_id = tbl_books.book_id AND tbl_borrow_details.borrow_id = tbl_borrow.borrow_id AND tbl_borrow.member_id = tbl_members.members_id AND borrow_status = 'RETURNED' 
	      		ORDER BY brw_detail_id DESC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-hover-pink w3-hover-text-black w3-border w3-border-aqua">
		      <td><?php echo $row['book_title'] ?><br>
		      		  <?php $date1 = date_create($row['date_returned']);
							$date2 = date_create($row['due_date']);
							$diff = date_diff($date1,$date2);
							//echo $diff->format("%R%a days");
							
							if ($diff->format("%R") == "-") {
								echo "<label class='w3-amber w3-wide'> OVERDUE </label>";
							}else{
								echo "<label class='w3-cyan w3-wide w3-text-black'> RETURNED </label>";
										  }?>					      			
		      </td>
		      <td>
		      	<?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?>
		      </td>
  		       <td>
		      	     RET :<?php echo $row['date_returned'] ?>
		      	<br> DUE :<?php echo $row['due_date'] ?>
		      </td>		    	 
		    </tr>
		    	
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
	

</div>




<div id="borrowed" class="<?php echo $containerLG ?> tab" style="display:none">
<div class="<?php echo $containerTabDGA ?>">
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="searcher" id="inputSearch2" onkeyup="searcher2()">
	<button class="w3-bar-item w3-button w3-hover-black w3-right"> <?php echo $imgView ?> FIND </button>
</div>

		<h4 class="<?php echo $headerDGA ?>"> BORROWED BOOKS TABLE </h4>
		<p><table class="<?php echo $table ?>" id="outputSearch2">
		  <tr class="w3-aqua w3-text-black">
		      <th>Book</th>
		      <th>Member</th>
		      <th>Action</th>

	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_borrow_details`,`tbl_books`,`tbl_members`,`tbl_borrow` WHERE tbl_borrow_details.book_id = tbl_books.book_id AND tbl_borrow_details.borrow_id = tbl_borrow.borrow_id AND tbl_borrow.member_id = tbl_members.members_id AND borrow_status != 'RETURNED' ORDER BY brw_detail_id DESC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-hover-pink w3-hover-text-black w3-border w3-border-aqua">
		      <td><?php echo $row['book_title'] ?>
		      	<br> DUE :<?php echo $row['due_date'] ?>
		      </td>
		      <td>
		      	<?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?>
		      </td>
  		       <td>
		     	 <form method="post" action="update_mod.php">
		     	 <input type="hidden" name="name_book" value="<?php echo $row['book_title'] ?>">
		     	 <input type="hidden" name="name_borrower" value="<?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?>">
		      	 	<button type="submit" value="<?php echo $row['brw_detail_id'] ?>" name="temp_retbook" class="<?php echo $buttonDGA; ?>"><?php echo $imgReturn ?></button>
		         </form>
		      </td>		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
	
</div>





</div>
</body>
</html>