<?php include 'header.php'; ?>

<div class="<?php echo $containerTabDGA ?>">
	<p class="w3-panel"><button onclick="document.getElementById('Adduser_modal').style.display='block'" class="<?php echo $buttonDG; ?>"> <img src="images/add.png" width="22px"> Create User Account </button></p>

	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="search" id="inputSearch" onkeyup="searcher()">
	<button class="w3-bar-item w3-button w3-hover-dark-gray w3-right"> <?php echo $imgView ?> FIND </button>
</div>


<!-- Modal for User  -->
  <div id="Adduser_modal" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom w3-black w3-text-aqua"> 
        <span onclick="document.getElementById('Adduser_modal').style.display='none'" 
        class="w3-button w3-display-topright w3-text-cyan">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> + Create User Account </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post">
		              
		    <div class="w3-row-padding">
		    	<p><label> Fullname </label>
		  			<input class="<?php echo $inputBC ?>" name="name" type="text" required></p>
		  		<p><label> Username </label>
		  			<input class="<?php echo $inputBC ?>" name="user" type="text" required></p>
		  		<p><label> Password </label>
		  			<input class="<?php echo $inputBC ?>" name="pass" type="password" required></p>
			</div>

		    <p class="w3-center">
		    <button name="add_user" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
		  </form>
    </div>
  </div>
<!-- Modal for User  -->

<div>
	<h4 class="<?php echo $headerDGA ?>"> USER TABLE </h4>
			
		<p><table class="<?php echo $table ?>" id="outputSearch" >
		  <thead class="w3-aqua w3-text-black">
		      <th>Full name</th>
		      <th>Account </th>
		      <th>Action</th>
	      </thead>
	      <?php
	      	$sql = "SELECT * FROM `tbl_users`";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td><?php echo $row['fullname'] ?></td>
		      <td>ID No: <?php echo $row['user_id'] ?>
		      	<br>USER: <?php echo $row['username'] ?>
		      </td>
		      	  
			      	 <td>
				   		<form method="post" action="update_mod.php">
				      	 <button type="submit" value="<?php echo $row['user_id'] ?>" name="editUser" class="<?php echo $buttonDGA; ?>"><?php echo $imgEdit ?></button>
				        </form>
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
</div>


</div>
</body>
</html>