<?php include 'header.php'; ?><p>

<div class="<?php echo $containerTabDGA ?>">
	<label class="w3-left w3-aqua w3-text-black w3-small">[ Select Report ]</label><br>
	<a href="reports.php">
	<button class="<?php echo $navbar1 ?>"> ALL </button></a>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('books')">BOOKS</button>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('members')">MEMBERS</button>
	<button class="<?php echo $navbar1 ?>" onclick="openCity('trans')">TRANSACTION</button>
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="" name="">
	<button class="w3-bar-item w3-button w3-hover-black w3-right"> <?php echo $imgView ?> FIND </button>
</div>
<p class="w3-center">
	<button onclick="window.printDiv('printableArea')" class="<?php echo $buttonDG; ?> "> <img src="images/add.png" width="22px"> PRINT </button></p>
	
</p>
<div class="<?php echo $containerLG ?>" id="printableArea">		
	<div id="books" class="<?php echo $containerLG ?> tab">

		<h4 class="<?php echo $headerDGA ?>"> BOOK REPORTS </h4>
		<p><table class="w3-table w3-bordered w3-light-gray w3-card-2 w3-strip" >
		  <tr class="w3-black w3-text-white">
		      <th>ISBN/TITLE</th>
		      <th>CATEGORY</th>
		      <th>STATUS</th>
		      <th>QTY</th>
		      <th>AUTHOR</th>
		      <th>PUBLISH</th>
		      <th>DATE</th>

	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_books`";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr>
		    <label class="w3-small">
		      <td><i><?php echo $row['book_isbn'] ?></i><br><?php echo $row['book_title'] ?></td>
		      	  <td><?php echo $row['book_category'] ?></td>
		      	  <td><?php echo $row['book_status'] ?></td>
		      	  <td><?php echo $row['books_copies'] ?></td>
		      	  <td><?php echo $row['book_auth'] ?></td>
		      	  <td><?php echo $row['book_pub_name'].",<br>".$row['book_pub_place']." - (".$row['book_copyright_yr'].')'?></td>
		      	  <td>REC: <?php echo $row['book_date_received'] ?>
		      	  <br>ADD: <?php echo $row['book_date_added'] ?></td>
		     </label>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
	</div>

		<div id="members" class="<?php echo $containerLG ?> tab">
			<h4 class="<?php echo $headerDGA ?>"> MEMBER TABLE </h4>			
			<p><table class="w3-table w3-bordered w3-light-gray w3-card-2 w3-strip" >
			  <tr class="w3-black w3-text-white">
		    	  <th>Member Account</th>
	    		  <th>Information</th>
		    	  <th>Action</th>
	      	</tr>
	      
	      <?php
	      	$sql = "SELECT * FROM `tbl_members`";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr>
		      <td>
		      	<i>ID #: </i><?php echo $row['members_id'] ?><br>
		      	<i>TYPE: </i><?php echo $row['mem_type'] ?><br>
		      	<i>STAT: </i><?php echo $row['mem_status'] ?></td>
		      <td>
		      	<i>NAME: </i><?php echo $row['mem_lastname'].",".$row['mem_firstname'] ?>
		      	<br><i>GENDER: </i><?php echo $row['mem_gender'] ?>
		      </td>
		      	  
	      	 <td>
				<i>ADDR: </i><?php echo $row['mem_address'] ?><br>
      			<i>CONT: </i><?php echo $row['mem_contact'] ?>
	      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
	</div>
	<div id="trans" class="<?php echo $containerLG ?> tab">
			<h4 class="<?php echo $headerDGA ?>"> BOOK TRANSACTION </h4>
			<p><table class="w3-table w3-bordered w3-light-gray w3-card-2 w3-strip">
		 	 <tr class="w3-black w3-text-white">
		  	    <th>Book</th>
		  	    <th>Member</th>
		   	    <th>Status</th>
	     	 </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_borrow_details`,`tbl_books`,`tbl_members`,`tbl_borrow` WHERE tbl_borrow_details.book_id = tbl_books.book_id AND tbl_borrow_details.borrow_id = tbl_borrow.borrow_id AND tbl_borrow.member_id = tbl_members.members_id";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr>
		      <td><?php echo $row['book_title'] ?></td>
		      <td>
		      	<?php echo $row['mem_firstname']." ".$row['mem_lastname'] ?>
		      </td>
  		       <td>
		      	<?php echo statusEcho($row['date_returned']) ?>
		      </td>		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
	</div>



</div>

</div>
</body>
</html>
<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}
</script>

<?php function statusEcho($date){

	if ($date == "") {
		return "PENDING";
	}else{
		return "RETURNED <br> ".$date;
	}

} ?>