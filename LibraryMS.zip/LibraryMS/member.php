<?php include 'header.php'; ?>

<div class="<?php echo $containerTabDGA ?>">
	<p class="w3-panel"><button onclick="document.getElementById('appt').style.display='block'" class="<?php echo $buttonDG; ?>"> <img src="images/add.png" width="22px"> Register Member </button></p>
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="searcher" id="inputSearch" onkeyup="searcher()">
	<button class="w3-bar-item w3-button w3-hover-dark-gray w3-right"> <?php echo $imgView ?> FIND </button>
</div>



<!-- Modal for member  -->
  <div id="appt" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom w3-card-4 w3-black w3-text-aqua"> 
        <span onclick="document.getElementById('appt').style.display='none'" 
        class="w3-button w3-display-topright w3-text-cyan">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> + Register Member </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="mem_form">
		              
		    <div class="w3-row-padding">
		    	<p><label> first name </label>
		  			<input class="<?php echo $inputBC ?>" name="fs" type="text" required></p>
		  		<p><label> last name </label>
		  			<input class="<?php echo $inputBC ?>" name="ls" type="text" required></p>
		  		<p><label> Address </label>
		  			<input class="<?php echo $inputBC ?>" name="adr" type="text" required></p>
		  		<p><label> Contact </label>
		  			<input class="<?php echo $inputBC ?>" name="con" type="text" required></p>
		  		<p><label> Gender </label>
		  			<select class="<?php echo $inputBC ?>" name="gen" form="mem_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select></p>
		  		<p><label> Type </label>
		  			<select class="<?php echo $inputBC ?>" name="typ" form="mem_form" required>
					  <option value="" disabled selected>Choose..</option>
<?php
$sql = "SELECT * FROM `tbl_type`";
$result = $conn->query($sql);
if ($result->num_rows > 0): ?>
<?php while ($row = $result->fetch_assoc()): ?>
					  <option value="<?php echo $row['borrower_type'] ?>"> <?php echo $row['borrower_type'] ?> </option>
	<?php endwhile ?>		      	
<?php endif ?></select></p>
	
		  		<p><label> Status </label>
		  			<select class="<?php echo $inputBC ?>" name="sts" form="mem_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="ACTIVE">ACTIVE</option>
						<option value="BANNED">BANNED</option>
					</select></p>
			</div>

		    <p class="w3-center">
		    <button type="submit" name="add_mem" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
		  </form>
    </div>
  </div>
<!-- Modal for member  -->

<div class="">
		<h4 class="<?php echo $headerDGA ?>"> MEMBER TABLE </h4>			
		<p><table class="<?php echo $table ?>" id="outputSearch" >
		  <tr class="w3-aqua w3-text-black">
		      <th>Member Account</th>
		      <th>Information</th>
		      <th>Action</th>
	      </tr>
	      
	      <?php
	      	$sql = "SELECT * FROM `tbl_members`";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td>
		      	<i>NAME: </i><?php echo $row['mem_lastname'].",".$row['mem_firstname'] ?>
		      	<br><i>GENDER: </i><?php echo $row['mem_gender'] ?>
		      	<br><i>ADDR: </i><?php echo $row['mem_address'] ?>
		      	<br><i>CONT: </i><?php echo $row['mem_contact'] ?>
		      </td>

		      <td>
		      	<i>ID #: </i><?php echo $row['members_id'] ?><br>
		      	<i>TYPE: </i><?php echo $row['mem_type'] ?><br>
		      	<i>STAT: </i><?php echo $row['mem_status'] ?>
		      </td>	  
			      	 <td>
				   		<form method="post" action="update_mod.php">
				      	 <button type="submit" value="<?php echo $row['members_id'] ?>" name="updmem" class="<?php echo $buttonDGA; ?>"><?php echo $imgEdit ?></button>
				        </form>
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
</div>


</div>
</body>
</html>