<?php include 'header.php'; ?>
<div class="<?php echo $containerTabDGA ?>">
	
	<p class="w3-panel"><button onclick="document.getElementById('appt').style.display='block'" class="<?php echo $buttonDG; ?> w3-left"> <img src="images/add.png" width="22px"> Book </button></p>
	<input class="<?php echo $inputBC ?> w3-bar-item w3-round-large w3-right" type="text" name="searcher" id="inputSearch" onkeyup="searcher()">
	<button class="w3-bar-item w3-button w3-hover-dark-gray w3-right"> <?php echo $imgView ?> FIND </button>
</div>


<!-- Modal for User  -->
  <div id="appt" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom w3-card-4 w3-black w3-text-aqua"> 
        <span onclick="document.getElementById('appt').style.display='none'" 
        class="w3-button w3-display-topright w3-text-cyan">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> + Register Book </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="book_form">
		              
		    <div class="w3-row-padding">
		    	<p><label> Book Title </label>
		  			<input class="<?php echo $inputBC ?>" name="title" type="text" required></p>
		  		<p><label> Category </label>
		  			<select class="<?php echo $inputBC ?>" name="cat" form="book_form" required>
					  <option value="" disabled selected>Choose..</option>
<?php
$sql = "SELECT * FROM `tbl_category`";
$result = $conn->query($sql);
if ($result->num_rows > 0): ?>
<?php while ($row = $result->fetch_assoc()): ?>
					  <option value="<?php echo $row['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
	<?php endwhile ?>		      	
<?php endif ?>

					</select></p>
		  		<p><label> Author </label>
		  			<input class="<?php echo $inputBC ?>" name="auth" type="text"></p>
		  		<p><label> Book Copies </label>
		  			<input class="<?php echo $inputBC ?>" name="qty" type="number"></p>
		  		<p><label> Book Publication </label>
		  			<input class="<?php echo $inputBC ?>" name="pubAddr" type="text" required></p>
		  		<p><label> Publisher Name </label>
		  			<input class="<?php echo $inputBC ?>" name="pubName" type="text" required></p>
		  		<p><label> ISBN </label>
		  			<input class="<?php echo $inputBC ?>" name="ISBN" type="number"></p>
		  		<p><label> Copyright Year </label>
		  			<input class="<?php echo $inputBC ?>" name="copyr" type="number" required></p>
	  			<p><label> Status </label>
				    <select class="<?php echo $inputBC ?>" name="stats" form="book_form" required>
					  <option value="" disabled selected>Choose..</option>
					  <option value="NEW"> NEW </option>
					  <option value="OLD"> OLD </option>
					  <option value="LOST"> LOST </option>
					  <option value="DAMAGE"> DAMAGE </option>
					  <option value="ARCHIVE"> ARCHIVE </option>
					  <option value="SUBJECT FOR REPLACEMENT">SUBJECT FOR REPLACEMENT</option>
					</select></p>
			</div>


		    <p class="w3-center">
		    <button name="add_bok" type="submit" class="<?php echo $buttonDGA; ?>"> CONFIRM </button></p>
		  </form>
    </div>
  </div>
<!-- Modal for User  -->

<div class="">
		<h4 class="<?php echo $headerDGA ?>"> BOOK TABLE </h4>
		<p><table class="<?php echo $table ?>" id="outputSearch">
		  <tr class="w3-text-black w3-aqua">
		      <th>Book</th>
		      <th>Details </th>
		      <th>Action</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_books` WHERE book_status !='ARCHIVE'";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td><label class="w3-medium">
		      	  <i>ISBN: </i><?php echo $row['book_isbn'] ?><br>
		      	  <i>Title: </i><?php echo $row['book_title'] ?><br>
  		      	  <i>Author: </i><?php echo $row['book_auth'] ?><br>
		      	  <i>Publisher: </i><?php echo $row['book_pub_name']." ,".$row['book_pub_place']?><br>
		      	  <i>Category: </i><?php echo $row['book_category'] ?><br>
		      	</label>
		      </td>
		      <td><label class="w3-medium">		      	
		      	  <i>QTY: </i><?php echo $row['books_copies'] ?><br>
		      	  <i>Status: </i><?php echo $row['book_status'] ?><br>
		      	  <i>Copyright: </i><?php echo $row['book_copyright_yr'] ?><br>
		      	  <i>REC: </i><?php echo $row['book_date_received'] ?>
		      	  <br><i> ADD: </i><?php echo $row['book_date_added'] ?>
		      	</label></td>

			      	 <td><br>
				   		<form method="post" action="update_mod.php">
				      	 <button type="submit" value="<?php echo $row['book_id'] ?>" name="upd_bok" class="<?php echo $buttonDGA; ?>"><?php echo $imgEdit ?></button>
				        </form>
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
</div>

</div>
</body>
</html>