
<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<h3 class="<?php echo $headerDGA ?>"> <?php echo $imgView ?><br> ADVANCE SEARCH </h3>

    <p><div class="w3-container w3-text-aqua"> 
	  <form class="w3-container" action="AdvanceSearch.php" method="post" id="src_search_form">
	    <div class="w3-row-padding">
	    	<label> Search Book </label>
  			<input class="<?php echo $inputBC ?>" name="src_book" type="text" >
  			<br>
  			 <p class="w3-center"> Search Filter </p>
  			
  			<label> Category </label	>
			<select class="<?php echo $inputBC ?>" name="src_cat" form="src_search_form" >
			<option value="ALL"> ALL </option>		  
			<?php
			$sql = "SELECT * FROM `tbl_category`";
			$result = $conn->query($sql);
			if ($result->num_rows > 0): ?>
			<?php while ($row = $result->fetch_assoc()): ?>
			  <option value="<?php echo $row['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
			<?php endwhile ?><?php endif ?>
			</select>

			<label> Status </label>
		    <select class="<?php echo $inputBC ?>" name="src_stat" form="src_search_form" >
			  <option value="ALL"> ALL </option>
			  <option value="NEW"> NEW </option>
			  <option value="OLD"> OLD </option>
			  <option value="LOST"> LOST </option>
			  <option value="DAMAGE"> DAMAGE </option>
			  <option value="ARCHIVE"> ARCHIVE </option>
			  <option value="SUBJECT FOR REPLACEMENT">SUBJECT FOR REPLACEMENT</option>
			</select>
			<label> Author </label>
  			<input class="<?php echo $inputBC ?>" name="src_aut" type="text" >
  			<label> Publisher </label>
  			<input class="<?php echo $inputBC ?>" name="src_pub" type="text" >
  	</p>

		</div>
		    <p class="w3-center">
		    <button type="submit" name="adv_search" class="<?php echo $buttonDGA; ?>"> SEARCH </button></p>
	  </form>
    </div></p><br>

<?php if (isset($_POST['adv_search'])): ?>

	<div class="w3-container w3-text-aqua">
<?php 

	$_POST['src_book'] = mysqli_real_escape_string($conn,$_POST['src_book']);
	$src_cat = mysqli_real_escape_string($conn,$_POST['src_cat']);
	echo $_POST['src_cat'];

if ($_POST['src_cat']!="ALL") { $cat=" AND book_category = '$src_cat'";}
if (isset($_POST['src_book'])) { $src_book=" WHERE book_title = '".$_POST['src_book']."' OR book_isbn = '".$_POST['src_book']."' ".$cat;}


 ?>

<p>
Result<br>
<table class="<?php echo $table ?>">
		  <tr class="w3-text-black w3-aqua">
		      <th>Book</th>
		      <th>Details </th>
		      <th>Action</th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_books`".$src_book;
	      	echo $sql;
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="w3-border w3-border-aqua w3-hover-pink w3-hover-text-black">
		      <td><label class="w3-medium">
		      	  <i>ISBN: </i><?php echo $row['book_isbn'] ?><br>
		      	  <i>Title: </i><?php echo $row['book_title'] ?><br>
  		      	  <i>Author: </i><?php echo $row['book_auth'] ?><br>
		      	  <i>Publisher: </i><?php echo $row['book_pub_name']." ,".$row['book_pub_place']?><br>
		      	  <i>Category: </i><?php echo $row['book_category'] ?><br>
		      	</label>
		      </td>
		      <td><label class="w3-medium">		      	
		      	  <i>QTY: </i><?php echo $row['books_copies'] ?><br>
		      	  <i>Status: </i><?php echo $row['book_status'] ?><br>
		      	  <i>Copyright: </i><?php echo $row['book_copyright_yr'] ?><br>
		      	  <i>REC: </i><?php echo $row['book_date_received'] ?>
		      	  <br><i> ADD: </i><?php echo $row['book_date_added'] ?>
		      	</label></td>

			      	 <td><br>
				   		<form method="post" action="update_mod.php">
				      	 <button type="submit" value="<?php echo $row['book_id'] ?>" name="upd_bok" class="<?php echo $buttonDGA; ?>"><?php echo $imgEdit ?></button>
				        </form>
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>
</div>
<?php endif ?>

<?php $_POST = array(); ?>

</body>
</html>

