
<?php include 'designs.php';?>
<?php include 'server_login.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>LMS LOGIN</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="main.css">
<link href="https://fonts.googleapis.com/css?family=Share+Tech+Mono" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-food.css">
</head>

<body style="background-image: url(Images/bg_web.jpg);">
	<div class="w3-top">
		<h1 class="<?php echo $headerDGA ?>"> LIBRARY MANAGEMENT SYSTEM</h1>
	</div>
<div class="w3-container" style="padding-top: 180px">

	<form method="post" action="login.php">
		<div class="w3-modal-content w3-black w3-border w3-border-aqua w3-padding w3-text-aqua" style="width: 30%">
		      	<div class="<?php echo $containerLG ?>">
				 	<h3 class="<?php echo $containerDGA?> w3-center">[Administrator]<br><br><?php echo $imgPass ?></h3>
				       	<p><label> Username</label>
				  			><input class="<?php echo $inputBC ?>" name="username" type="text"></p>

						<p><label> Password </label>
				  			><input class="<?php echo $inputBC ?>" name="password" type="password"></p>
				  			
			  			<p class="w3-center"><button type="submit" class="<?php echo $buttonDGA ?>" name="login_user"> Log In </button></p>
				  		<center><?php include('errors.php');?></center>	
				</div>
		</div>
	</form>
</div>				
	
	

</body>
</html>