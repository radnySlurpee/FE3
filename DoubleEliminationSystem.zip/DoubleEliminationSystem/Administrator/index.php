<?php include "header.php" ?>

<div class="w3-row w3-center"><br>
    <div class="w3-half w3-animate-left">
      	 	<?php include 'menu.php'; ?>
    </div>

    <div class="w3-half w3-animate-right">
    	 <p class="w3-panel w3-animate-zoom"><img src="Images/aclcISO.png" style="width: 400px"></p>
    </div>

</div>
	<div class="">
		<h1 class="w3-center w3-padding w3-wide"> <label class="w3-white w3-opacity-min">[ THE HOUSES ] </label></h1>
		  <div class="w3-row w3-center w3-padding">
		    <div class="w3-quarter">
		      <img src="Images/houses/azul.png" style="width:210px">
		    </div>
		    <div class="w3-quarter">
		      <img src="Images/houses/roxxo.png" style="width:150px">
		    </div>
		    <div class="w3-quarter">
		      <img src="Images/houses/vierrdy.png" style="width:170px">
		    </div>
		        <div class="w3-quarter">
		      <img src="Images/houses/cahel.png" style="width:170px">
		    </div>
		  </div>

  		  <div class="w3-row w3-center w3-padding">
		    <div class="w3-third">
		      <img src="Images/houses/giallio.png" style="width:210px">
		    </div>
		    <div class="w3-third">
		      <img src="Images/houses/black_mambas.png" style="width:150px">
		    </div>
		    <div class="w3-third">
		      <img src="Images/houses/white_scorpion.png" style="width:170px">
		    </div>
		  </div>


	</div>
<?php include "footer.php" ?>