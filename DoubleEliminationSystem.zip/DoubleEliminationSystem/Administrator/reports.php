<?php include "header.php" ?>

<div class="<?php echo $divBW ?>">
	<h1 class="<?php echo $headerBW ?>">
	 <?php echo $imgRhom ?> REPORTS </h1>
</div>
 
 <div class="w3-row" style="min-width: 500px;">

  <div class="w3-half w3-container">
	<p class="w3-panel">
	<input class="<?php echo $SearchBox ?>" placeholder="Search.." type="text" name="search" id="inputSearch" onkeyup="searcher()">

		<?php include 'menu.php'; ?>
		<?php include "insert_modal.php"; ?>
  </p>
  </div>

  <div class="w3-half w3-container w3-animate-zoom">

	<h6 class="w3-black w3-center"> 
		<label class="w3-white w3-padding-small"> {}  </label>
	</h6>
	<p class="w3-panel w3-center">
	</p>

   <p><table class="<?php echo $table ?>" id="outputSearch">
		  <tr class="<?php echo $trhead ?>">
		      <th>MATCH </th>
		      <th>STATUS </th>
		      <th>ACTION </th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_match` ORDER BY match_year DESC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		      <td>
		      	 <?php echo $row['match_category']." ".$row['match_division']." DIVISION"."
		      	  ".$row['match_year'] ?><br>
		      	  <label class="w3-black w3-padding-small w3-small">
		      	  	ID: <?php echo $row['match_id'] ?></label>
		      </td>
		      <td> 
		      	<?php echo $row['match_status'] ?>
		      	 
		      </td>
	      	  <td>
		   		<form method="post" action="update_modal.php">

			      	 <button type="submit" value="<?php echo $row['match_id'] ?>" name="printMatch" class="<?php echo $btnAct; ?>" ><?php echo $imgBracketEdit ?></button>

		      	</form>
	      	  </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p> 
  </div>

</div>

<?php include "footer.php" ?>