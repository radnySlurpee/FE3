<?php include 'designs.php' ?>
<?php include 'connection.php' ?>
<!DOCTYPE html>
<html>
<head>
	<title>Double Elimination System</title>
<meta name = "viewport" content = "width = device-width">
<link rel="shortcut icon" href="Images/aclcLogo.png"/>
<link rel="stylesheet" href="main.css">
<link rel="stylesheet" href="colorScheme.css">
<link rel="stylesheet" href="inputDesign.css">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<style type="text/css">
@import url('https://fonts.googleapis.com/css?family=Barlow:900');
@import url('https://fonts.googleapis.com/css?family=Share+Tech+Mono');

.fontBarlow {
  font-family: 'Barlow', sans-serif;
}

.blurwhite{
  min-height: 200px;
  background-image: url(Images/minimalWhite.jpg);
}

.parallax {
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

button,a,tbody tr:hover{
    -webkit-transition-duration: 0.4s; /* Safari */
     transition-duration: 0.4s;
}

*:focus {
    outline: none;
}
label,h1,h2,h3,img,th {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
</style>

<body class="">


<div class=""  style="min-width: 500px;">
  <p class="w3-panel w3-black w3-card-4" style="width: 100%"><img src="Images/aclc.jpg" style="width: 190px">
    <a href="" class="w3-button w3-right w3-hover-pink w3-hover-text-black">LOGOUT<br>
      {<?php echo $imgLogout ?>}</a></p>
<script type="text/javascript">

function openCity(cityName)
{
    var i;
    var x = document.getElementsByClassName("tab");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
}
</script>

<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}
</script>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function w3_open() {
    if (mySidebar.style.display === 'block') {
        mySidebar.style.display = 'none';
        overlayBg.style.display = "none";
    } else {
        mySidebar.style.display = 'block';
        overlayBg.style.display = "block";
    }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
    overlayBg.style.display = "none";
}
</script>

<script>
function searcher() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("inputSearch");
  filter = input.value.toUpperCase();
  table = document.getElementById("outputSearch");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}

function accordion(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}

</script>
