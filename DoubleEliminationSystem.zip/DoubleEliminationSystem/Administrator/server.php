<?php
include 'designs.php';

$GLOBALS['hdr'] = "refresh:1000; url=index.php";
$GLOBALS['last_ID'] ='0';

//initiator
if (isset($_POST['insert_player'])) {
    insertPlayer();
}
if (isset($_POST['update_player'])){
    updatePlayer();
}
if (isset($_POST['delete_player'])){
    deletePlayer();
}
if (isset($_POST['insert_user'])){
    insertUser();
}
if (isset($_POST['update_user'])){
    updateUser();
}
if (isset($_POST['insert_cat'])){
    insertCategory();
}
//To be Continued..
RandomSeed('1','VIERRDY');


function BracketMove($win,$lose,$MoveWinner,$MoveLoser,$matchID){
    
    $paramList = array();
    $paramList[] = $win;
    $paramList[] = $MoveWinner;
    $paramList[] = $matchID;
    //winner
    execQuery($paramList, 
    'UPDATE `tbl_match_res` SET `bracket_house`=? 
     WHERE `match_id`=? AND `bracket_no`=?', "");

    $paramList = array();
    $paramList[] = $lose;
    $paramList[] = $MoveLoser;
    $paramList[] = $matchID;
    //loose
    execQuery($paramList, 
    'UPDATE `tbl_match_res` SET `bracket_house`=? 
     WHERE `match_id`=? AND `bracket_no`=?', "");
}


function RandomSeed($matchID,$team1){//Insert Match Results

$houses = array();
$seedTeam = array();
$bracketNo = array();

$bracketNo = array("T1","T2","T3","T4","T5","T6","T7",
                   "W1","W2","W3","W4","W5","W6","W7","W8","W9","W10","W11","W12","W13",
                    "L1","L2","L3","L4","L7","L9");
$houses = array("AZUL","BLACK MAMBA", "CAHEL","GIALLIO","ROXXO","VIERRDY","WHITE SCORPIONS");
$matchNumber = array('1','2','3','4','5','6','7','8','9','10','11','12','13');

shuffle($houses);
//selecting a bracket for team 1
foreach ($houses as $house) {
   if ($team1 != $house) {
        $seedTeam[] = $house;
   }
}

$time1 = date('H:i', strtotime('09:00'));//starting time

$seedTeam[] = $team1;
$seedTeam =  array_reverse($seedTeam);
echo $seedTeam[0];
foreach ($bracketNo as $bracket) {
    echo "<br>";
    $time1 = date('H:i', strtotime($time1.'+30 minutes'));//duration
    echo '("2","'.$bracket.'",""),';

}

foreach ($seedTeam as $seed) {
    echo "<br>";
    echo $seed;

    // foreach($_POST["book"] as $book)
    // {
        
    //     $paramList = array();
    //     $paramList[] = $book;
    //     $paramList[] = $matchID;
    //     $paramList[] = "PENDING";
    //     $paramList[] = "NULL";

    //     execQuery($paramList, 
    //     'INSERT INTO `tbl_borrow_details`(`book_id`, `borrow_id`, `borrow_status`, `date_returned`) VALUES (?,?,?,?)',"Location:transaction.php");
        
    // }
}




}

//after process
   $msg = "<br> Nothing to see here <br> :) <br> ";
   header($hdr);

?>

<?php
function insertPlayer(){

    $paramList = array();
    $paramList[] = $_POST['fs'];
    $paramList[] = $_POST['ls'];
    $paramList[] = $_POST['gen'];
    $paramList[] = $_POST['house'];
    $paramList[] = $_POST['cat'];
    $paramList[] = $_POST['stats'];

    execQuery($paramList, 
    'INSERT INTO `tbl_player`(`play_fn`, `play_ls`, `play_gender`, `play_house`, `play_category`, `play_status`) VALUES (?,?,?,?,?,?)', "Location:player.php");
}

function updatePlayer(){

    $paramList = array();
    $paramList[] = $_POST['fs'];
    $paramList[] = $_POST['ls'];
    $paramList[] = $_POST['gen'];
    $paramList[] = $_POST['house'];
    $paramList[] = $_POST['cat'];
    $paramList[] = $_POST['stats'];
    $paramList[] = $_POST['play_id'];

    execQuery($paramList, 
    'UPDATE `tbl_player` SET `play_fn`=?,`play_ls`=?,`play_gender`=?,`play_house`=?,`play_category`=?,`play_status`=? WHERE `player_id`=?', "Location:player.php");
}

function deletePlayer(){

    $paramList = array();
    $paramList[] = $_POST['play_id'];

    execQuery($paramList,'DELETE FROM `tbl_player` WHERE `player_id`=?', "Location:player.php");
}

function insertUser(){

    $paramList = array();
    $paramList[] = $_POST['user'];
    $paramList[] = $_POST['pass'];
    $paramList[] = $_POST['type'];
    $paramList[] = $_POST['stat'];

    execQuery($paramList, 
    'INSERT INTO `tbl_users`(`username`, `password`, `user_type`, `user_status`) VALUES (?,?,?,?)',
    "Location:user.php");
}

function updateUser(){

    $paramList = array();
    $paramList[] = $_POST['user'];
    $paramList[] = $_POST['pass'];
    $paramList[] = $_POST['type'];
    $paramList[] = $_POST['stat'];
    $paramList[] = $_POST['usr_id'];

    execQuery($paramList, 
    'UPDATE `tbl_users` SET `username`=?,`password`=?,`user_type`=?,`user_status`=? WHERE `user_id`=?',
    "Location:user.php");
}

function insertCategory(){

    $paramList = array();
    $paramList[] = $_POST['catname'];
    $paramList[] = $_POST['nummax'];

    execQuery($paramList,'INSERT INTO `tbl_category`(`category_name`, `cat_max_player`) VALUES (?,?)', "Location:category.php");
}
function updateCategory(){
    
}

function insertMatch(){

}
//Function For Query

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// $stmt = The SQL Statement Object
// $param = Array of the Parameters
function AddParams($stmt, $params)
{
    if ($params != null)
    {
        // Generate the Type String (eg: 'issisd')
        $types = '';
        foreach($params as $param)
        {
            if(is_int($param)) {
                // Integer
                $types .= 'i';
            } elseif (is_float($param)) {
                // Double
                $types .= 'd';
            } elseif (is_string($param)) {
                // String
                $types .= 's';
            } else {
                // Blob and Unknown
                $types .= 'b';
            }
        }
  
        // Add the Type String as the first Parameter
        $bind_names[] = $types;
  
        // Loop thru the given Parameters
        for ($i=0; $i<count($params);$i++)
        {
            // Create a variable Name
            $bind_name = 'bind' . $i;
            // Add the Parameter to the variable Variable
            $$bind_name = $params[$i];
            // Associate the Variable as an Element in the Array
            $bind_names[] = &$$bind_name;
        }
         
        // Call the Function bind_param with dynamic Parameters
        call_user_func_array(array($stmt,'bind_param'), $bind_names);
    }
    return $stmt;
}

function execQuery($paramList,$query,$hdr){
    include "connection.php";
    $stmt = $conn->prepare($query);
    AddParams($stmt, $paramList);
    $stmt->execute();
    $GLOBALS['last_ID'] = $stmt->insert_id;
    $stmt->close(); 
    $conn->close();
    
    if ($hdr!="") {
        $GLOBALS['hdr'] = "$hdr";
    }
   
}

 ?>

 <!DOCTYPE html>
 <html>
<head>
    <title></title>
<link rel="stylesheet" href="main.css">
<link rel="stylesheet" href="colorScheme.css">
<link rel="stylesheet" href="inputDesign.css">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link href="https://fonts.googleapis.com/css?family=Share+Tech+Mono" rel="stylesheet">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-food.css">
<link href="https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed:900" rel="stylesheet">
</head>
 <body class="w3-white" style="font-size: 20px">
    <h1 class="w3-center">
        <img src="Images/rhom.png" width="100px">
        <br>
        <?php echo $msg ?>
        </h1>

 </body>
 </html> 


