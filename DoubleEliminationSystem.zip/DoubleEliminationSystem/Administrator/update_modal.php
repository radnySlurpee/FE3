<?php include 'header.php'; ?>
<br>
<?php 

	function GenderDivision($gen){
		if ($gen == "WOMENS") {
			return 'FEMALE';
		}else{
			return 'MALE';
		}
	}

	function buttonBracket($Name,$bracketNumber,$Height,$Width,$top,$left){

		if ($bracketNumber == "") {
			$readonly = "visibility:hidden";
		}else{
			$readonly = "";
		}

		echo '<button class="w3-button w3-border w3-border-black '.colorbox($bracketNumber).'" ';
		echo 'name="'.$Name.'" value="'.$bracketNumber.'"';
		echo 'style="height: '.$Height.'; width: '.$Width.'; 
		      margin-top :'.$top.';margin-left :'.$left.';
		      '.$readonly.' ">';
		echo $bracketNumber;
		echo '</button>';
	}
 ?>

<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}
</script>

<?php if (isset($_POST['editPlayer'])): ?><!-- Modal for player  -->
<?php $ID = $_POST['editPlayer'];
$sql = "SELECT * FROM `tbl_player` WHERE player_id = '$ID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>

	<div class="w3-modal-content w3-animate-zoom blurwhite parallax w3-card-2"> 
		<a href="player.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">&times;</a>	  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> EDIT PLAYER </h2>
		</div>
		  <form class="w3-container" action="server.php" method="post" id="plyr_form">
		              
		    <div class="w3-row-padding">

		    	<input type="hidden" name="play_id" value="<?php echo $row['player_id'] ?>">

		    	<p><label class="<?php echo $label ?>"> First name : </label>
		  			<input class="<?php echo $input ?>" name="fs" type="text" required 
		  			value="<?php echo $row['play_fn'] ?>"></p>

		  		<p><label class="<?php echo $label ?>"> Last name : </label>
		  			<input class="<?php echo $input ?>" name="ls" type="text" required 
		  			value="<?php echo $row['play_ls'] ?>"></p>

		  		<p><label class="<?php echo $label ?>"> Gender : </label>
		  			<select class="<?php echo $input ?>" name="gen" form="plyr_form" required>
					  <option value="<?php echo $row['play_gender'] ?>" selected>
					  	<?php echo $row['play_gender'] ?></option>
						<option value="MALE">Male</option>
						<option value="FEMALE">Female</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> House : </label>
		  			<select class="<?php echo $input ?>" name="house" form="plyr_form" required>
					  <option value="<?php echo $row['play_house'] ?>" selected>
					  	<?php echo $row['play_house'] ?></option>
						<option value="AZUL">AZUL</option>
						<option value="CAHEL">CAHEL</option>
						<option value="GIALLIO">GIALLIO</option>
						<option value="ROXXO">ROXXO</option>
						<option value="VIERRDY">VIERRDY</option>
						<option value="BLACK MAMBA">BLACK MAMBA</option>
						<option value="WHITE SCORPIONS">WHITE SCORPIONS</option>
					</select></p>
		  		<p><label class="<?php echo $label ?>"> Game Category : </label>
		  			<select class="<?php echo $input ?>" name="cat" form="plyr_form" required>
					  <option value="<?php echo $row['play_category'] ?>" selected>
					  	<?php echo $row['play_category'] ?></option>
				<?php
				$sql = "SELECT * FROM `tbl_category`";
				$result = $conn->query($sql);
				if ($result->num_rows > 0): ?>
				<?php while ($rowC = $result->fetch_assoc()): ?>
						  <option value="<?php echo $rowC['category_name'] ?>"> <?php echo $rowC['category_name'] ?> </option>
				<?php endwhile ?>		      	
				<?php endif ?>
					</select></p>

				<p><label class="<?php echo $label ?>"> Status : </label>
		  			<select class="<?php echo $input ?>" name="stats" form="plyr_form" required>
					  <option value="<?php echo $row['play_status'] ?>" selected>
					  	<?php echo $row['play_status'] ?></option>
						<option value="SELECTED">Selected</option>
						<option value="RESERVED">Reserved</option>
					</select></p>

			</div>

		    <p class="w3-center">
		    <button name="update_player" type="submit" class="<?php echo $btnBW; ?>"> UPDATE </button></p>
		  </form>
	</div>

<?php endwhile ?><?php endif ?>
<?php endif ?><!-- Modal for player  -->

<?php if (isset($_POST['delPlayer'])): ?><!-- Modal for player  -->
<?php $ID = $_POST['delPlayer'];
$sql = "SELECT * FROM `tbl_player` WHERE player_id = '$ID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>

	<div class="w3-modal-content w3-animate-zoom blurwhite parallax w3-card-2"> 
		<a href="player.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black ">&times;</a>	  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> DO YOU WANT TO <br> DELETE THIS PLAYER ? </h2>
		</div>
		  <form class="w3-container" action="server.php" method="post" id="plyr_form">
		              
		    <div class="w3-row-padding">

		    	<input type="hidden" name="play_id" value="<?php echo $row['player_id'] ?>">

		    	<p><label class="<?php echo $label ?>"> Player name : </label>
		  			<input class="<?php echo $input ?>" name="play_name" type="text" required 
		  			value="<?php echo $row['play_fn']." ".$row['play_ls'] ?>"></p>

			</div>

		    <p class="w3-center">
		    <button name="delete_player" type="submit" class="<?php echo $btnBW; ?>"> YES </button></p>
		  </form>
	</div>

<?php endwhile ?><?php endif ?>
<?php endif ?><!-- Modal for player  -->



<?php if (isset($_POST['editUser'])): ?><!-- Modal for user  -->
<?php $ID = $_POST['editUser'];
$sql = "SELECT * FROM `tbl_users` WHERE user_id = '$ID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>

 <div class="w3-modal-content w3-animate-zoom blurwhite parallax w3-card-2"> 
		<a href="user.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">&times;</a>
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> EDIT USER </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="user_form">
		              
		    <div class="w3-row-padding">

		    	<input type="hidden" name="usr_id" value="<?php echo $row['user_id'] ?>">

		    	<p><label class="<?php echo $label ?>"> Username: </label>
		  			<input class="<?php echo $input ?>" name="user" type="text" required 
		  			value="<?php echo $row['username'] ?>" ></p>

		  		<p><label class="<?php echo $label ?>"> Password : </label>
		  			<input class="<?php echo $input ?>" name="pass" type="password" required
		  			value="<?php echo $row['password'] ?>" ></p>

		  		<p><label class="<?php echo $label ?>"> TYPE : </label>
		  			<select class="<?php echo $input ?>" name="type" form="user_form" required>
					  <option value="<?php echo $row['user_type'] ?>" selected>
					  	<?php echo $row['user_type'] ?></option>
						<option value="ADMIN">ADMIN</option>
						<option value="ARBITER">ARBITER</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> STATUS : </label>
		  			<select class="<?php echo $input ?>" name="stat" form="user_form" required>
					  <option value="<?php echo $row['user_status'] ?>" selected>
					  	<?php echo $row['user_status'] ?></option>
						<option value="ACTIVE">ACTIVE</option>
						<option value="INACTIVE">INACTIVE</option>
					</select></p>
			</div>

		    <p class="w3-center">
		    <button name="update_user" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>
<?php endwhile ?><?php endif ?>
<?php endif ?><!-- Modal for user  -->


<?php if (isset($_POST['editCat'])): ?><!-- Modal for category  -->
<?php $ID = $_POST['editCat'];
$sql = "SELECT * FROM `tbl_category` WHERE category_name = '$ID'"; 
$result = $conn->query($sql);	
if ($result->num_rows > 0): ?><?php while ($row = $result->fetch_assoc()): ?>

    <div class="w3-modal-content w3-animate-zoom blurwhite parallax w3-card-2"> 
       <a href="category.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">&times;</a>	  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> EDIT GAME CATEGORY </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="cat_form">
		              
		    <div class="w3-row-padding">
		    		<input type="hidden" name="catID" value="<?php echo $row['category_name'] ?>" >
		    	<p><label class="<?php echo $label ?>"> Category Name : </label>
		  			<input class="<?php echo $input ?>" name="catname" type="text" required
		  			value="<?php echo $row['category_name'] ?>" ></p>

		  		<p><label class="<?php echo $label ?>"> Max no. of Players per houses : </label>
		  			<input class="<?php echo $input ?>" name="nummax" type="number" required
		  			value="<?php echo $row['cat_max_player'] ?>" ></p>
			</div>

		    <p class="w3-center">
		    <button name="update_cat" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>

   <?php endwhile ?><?php endif ?>
<?php endif ?><!-- Modal for category  -->


<!-- Modal for bracket  -->
<?php if (isset($_POST['editBracket'])):?>
	
	<?php
	$bracketVar=array();
	$ID = $_POST['editBracket'];
	$sql = "SELECT * FROM `tbl_match_res`,`tbl_match` 
	        WHERE tbl_match.match_id = '$ID' 
	        AND tbl_match_res.match_id = tbl_match.match_id"; 
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
				//echo BracketVar("T2",$row['bracket_no'],$row['bracket_house']);
			$bracketVar[$row['bracket_no']] = $row['bracket_house'];
			$match_name = $row['match_category']." ".$row['match_division'].
						  " DIVISION"." ".$row['match_year'];
			$match_id = $row['match_id'];
			$genderDiv = GenderDivision($row['match_division']);


		}
	}	
	//print_r($bracketVar);
?>

   <div class="w3-mobile"> 
    
	  <div class="w3-container w3-wide">
	    <h2><?php echo $imgRhom ?> MATCH BRACKET  <label class="w3-right">
	    	<a href="match.php" class="w3-button w3-hover-dark-gray w3-black">&times;</a> 
	    </label></h2>
	    <p class="w3-black w3-large w3-panel w3-text-white w3-padding"> <?php echo $match_name?> 
	    <br>MATCH ID: <?php echo $match_id ?></p>
	  </div>
	  <form class="w3-container" action="server.php" method="post" id="cat_form">
	  <div class="w3-container" style="overflow-x: auto">
	    <div class="" style="background-image: url('Images/eliminationbackground.png');
	     background-repeat: no-repeat; min-width: 1041px;min-height: 581px;">

			<!-- first row -->
			  <div class="w3-padding w3-container" 
			  style="height: 90px; width: 120px; margin-top:40px;">
			  	  <!-- T2 -->
				 <?php buttonBracket('T2',$bracketVar['T2'],'41px','105px','11px','4px') ?>  	
			 	 <!-- T3 -->
			 	 <?php buttonBracket('T3',$bracketVar['T3'],'41px','105px','0px','4px') ?>

			 </div>
			 
			 <div class="w3-padding w3-container " 
			 style="height: 100px; width: 113px; margin-top:42px;margin-left :4px">
			 	 <!-- T4 -->
				 <?php buttonBracket('T4',$bracketVar['T4'],'40px','105px','auto','auto') ?>
				 <!-- T5 -->
				 <?php buttonBracket('T5',$bracketVar['T5'],'41px','105px','auto','auto') ?>
			 
			 </div>

			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
			  	  <!-- T6 -->
			  	  <?php buttonBracket('T6',$bracketVar['T6'],'40px','105px','auto','auto') ?>  
			 	  <!-- T7 -->
				  <?php buttonBracket('T7',$bracketVar['T7'],'41px','105px','auto','auto') ?>
			    </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
				 <!-- L1 -->
				 <?php buttonBracket('L1',$bracketVar['L1'],'40px','105px','auto','auto') ?> 
			     <!-- L2 -->
			     <?php buttonBracket('L2',$bracketVar['L2'],'40px','105px','auto','auto') ?> 
			   </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;;margin-left :4px">
			  <!-- L3 -->
			  <?php buttonBracket('L3',$bracketVar['L3'],'40px','105px','auto','auto') ?>    
			  <!-- L4 -->
			  <?php buttonBracket('L4',$bracketVar['L4'],'40px','105px','auto','auto') ?>
			 </div>
			   <!--end -->


			<!-- second bracket -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:-600px; margin-left: 207px;">
			    <!--T1 -->
				<?php buttonBracket('T1',$bracketVar['T1'],'40px','105px','auto','auto') ?>  
			    <!--W1 -->
				<?php buttonBracket('W1',$bracketVar['W1'],'41px','105px','auto','auto') ?>
			 </div>

			 <div class="w3-padding w3-container" 
			 style=" height:228px ; width: 113px; margin-left: 207px;">
			 	<!--W2 -->
			 	<?php buttonBracket('W2',$bracketVar['W2'],'41px','105px','60px','auto') ?>
			 	<!--W3 -->
			 	<?php buttonBracket('W3',$bracketVar['W3'],'41px','105px','79px','auto') ?>
			 </div>

			<div class="w3-padding w3-container"
			 style=" height:228px ; width: 113px; margin-left: 207px;">
				<!--W5 -->
				<?php buttonBracket('W5',$bracketVar['W5'],'41px','105px','72px','auto') ?>
				<!--W6 -->
				<?php buttonBracket('W6',$bracketVar['W6'],'41px','105px','79px','auto') ?>
				</div>
			<!-- end -->

			<!-- 3rd bracket -->
			<div class="w3-padding w3-container" 
			style=" height:240px ; width: 113px; margin-left: 407px; margin-top:-529px;">
			   <!--W4 -->
			   <?php buttonBracket('W4',$bracketVar['W4'],'41px','105px','-7px','auto') ?>
			   <!--W7 -->
			   <?php buttonBracket('W7',$bracketVar['W7'],'41px','105px','159px','auto') ?>
			 </div>

			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:153px; margin-left: 407px;">
				<!--L7 -->
				<?php buttonBracket('L7',$bracketVar['L7'],'41px','105px','auto','auto') ?> 
				<!--W8 -->
				<?php buttonBracket('W8',$bracketVar['W8'],'41px','105px','auto','auto') ?>
			 </div>

			<!-- end-->

			<!-- 4th bracket -->
			<div class="w3-padding w3-container" 
			 style=" height:240px ; width: 113px; margin-left: 614px; margin-top:-393px;">
			 <!--W9 -->
			 <?php buttonBracket('W9',$bracketVar['W9'],'41px','101px','-7px','auto') ?>
			 <!--W11 -->
			 <?php buttonBracket('W11',$bracketVar['W11'],'41px','105px','139px','auto') ?>
			 </div>

			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin-top:33px; margin-left: 614px;">
			  <!--L9 -->
			  <?php buttonBracket('L9',$bracketVar['L9'],'41px','100px','auto','auto') ?>
			  <!--W10 -->
			  <?php buttonBracket('W10',$bracketVar['W10'],'41px','100px','auto','auto') ?>	
			</div>

			<!-- end -->

			<!-- 5th bracket -->
			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin:auto; margin-top:-330px; margin-left: 735px;">
			  <!--W9 -->
  			  <?php buttonBracket('W9',$bracketVar['W9'],'41px','98px','auto','auto') ?>	  
			  <!--W12 -->
  			  <?php buttonBracket('W12',$bracketVar['W12'],'41px','98px','auto','auto') ?>
			</div>

			<!-- end -->

			<!--CHAMPION :) W13-->
			<?php buttonBracket('W13',$bracketVar['W13'],'41px','105px','-130px','951px') ?>
			 </div>
			<!-- end -->
	  </form>
  </div>
   </div><!-- Modal for bracket  -->
<br><br>

   	<div class="w3-container w3-card-4">
	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>CHAMPION </th>
		      <th>SECOND PLACE</th>
		      <th>THIRD PLACE</th>
	      </tr>
	      <tr class="<?php echo $trhead ?>">
		      <td class="<?php echo colorbox($bracketVar['W13']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W13'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['W9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W9'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['L9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['L9'] ?></td>
	      </tr>
	  </table>
	</div>
<br><br>
	<div class="w3-container w3-card-4">
	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>HOUSE </th>
		      <th>PLAYER </th>
		      <th>  </th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_match`,`tbl_player` WHERE tbl_match.match_id = '$ID' AND tbl_match.match_category = tbl_player.play_category AND tbl_player.play_gender ='$genderDiv' AND tbl_player.play_status ='SELECTED' ORDER BY tbl_player.play_house ASC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		      <td class="">
		      	<label class="<?php echo colorboxPlayer($row['play_house']) ?>">
		      	  <?php echo $row['play_house'] ?></label>
		      </td>
		      
		      <td> <?php echo $row['play_ls'].", ".$row['play_fn'] ?> </td>
		      	  
		      	 <td>
		      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		</table></p> 
	</div>
<?php endif ?>

<?php if (isset($_POST['editMatch'])): ?>

	<div class="w3-modal-content w3-animate-zoom blurwhite"> 
        <a href="match.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">
         &times;</a> 	  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> EDIT MATCH </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="match_form">
		              
		    <div class="w3-row-padding">
		  		<p><label class="<?php echo $label ?>"> Change TEAM 1 bracket : </label>
		  			<select class="<?php echo $input ?>" name="house" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="AZUL">AZUL</option>
						<option value="CAHEL">CAHEL</option>
						<option value="GIALLIO">GIALLIO</option>
						<option value="ROXXO">ROXXO</option>
						<option value="VIERRDY">VIERRDY</option>
						<option value="BLACK MAMBA">BLACK MAMBA</option>
						<option value="WHITE SCORPIONS">WHITE SCORPIONS</option>
					</select>
					<label class="w3-red w3-medium w3-padding-small w3-border w3-border-black">
					 WARNING : Changing the team 1 Bracket will RESET the match </label>
				</p>

		  		<p><label class="<?php echo $label ?>"> Game Category : </label>
		  			<select class="<?php echo $input ?>" name="cat" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
				<?php
				$sql = "SELECT * FROM `tbl_category`";
				$result = $conn->query($sql);
				if ($result->num_rows > 0): ?>
				<?php while ($row = $result->fetch_assoc()): ?>
						  <option value="<?php echo $row['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
				<?php endwhile ?>		      	
				<?php endif ?>
					</select></p>

				<p><label class="<?php echo $label ?>"> Gender Division : </label>
		  			<select class="<?php echo $input ?>" name="gendiv" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="MENS">MENS</option>
						<option value="WOMENS">WOMENS</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> Year : </label>
		  			<input class="<?php echo $input ?>" name="yr" type="number" required min="2010" 
		  			placeholder="0000" ></p>

				<p><label class="<?php echo $label ?>"> Arbiter Assign : </label>
		  			<select class="<?php echo $input ?>" name="gendiv" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>

					<?php
					$sql = "SELECT * FROM `tbl_users` WHERE user_type='ARBITER'";
					$result = $conn->query($sql);
					if ($result->num_rows > 0): ?>
					<?php while ($row = $result->fetch_assoc()): ?>
					  <option value="<?php echo $row['user_id'] ?>"> 
					  <?php echo $row['username'] ?> </option>
					<?php endwhile ?>		      	
					<?php endif ?>

					</select></p>

				<p><label class="<?php echo $label ?>"> Match Status : </label>
		  			<select class="<?php echo $input ?>" name="mstat" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="LOCK">LOCK</option>
						<option value="UNLOCK">UNLOCK</option>
						<option value="UNLOCK">SHOW</option>
					</select></p>
					<br>
		  	   </p>
			
			</div>
		    <p class="w3-center">
		    <button name="update_match" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button>
		    <label class="w3-right w3-red w3-round-xlarge">
		    <button name="reset_match" type="submit" class="<?php echo $btnBW; ?>"> RESET </button></label></p>
		  </form>
    </div>
<?php endif ?>

<?php if (isset($_POST['editSched'])): ?>
	<div class="w3-modal-content w3-animate-zoom blurwhite"> 
        <a href="schedule.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">
         &times;</a> 	  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> EDIT QUICK SCHEDULE </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="match_form">
		              
		    <div class="w3-row-padding">
			  	<p><label class="<?php echo $label ?>"> Starting Date : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="date" required></p>
		  		<p><label class="<?php echo $label ?>"> Starting Time : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="time" required></p>
		  		<p><label class="<?php echo $label ?>"> No. of Days : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="number" required min="1"></p>
		  		<p><label class="<?php echo $label ?>"> Duration per Match (minutes) : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="number" required min="10">
				</div>

		    <p class="w3-center">
		    <button name="update_match" type="submit" 
		    class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div></p>
<?php endif ?>

<?php if (isset($_POST['viewSched'])): ?>

	<div class="w3-modal-content w3-animate-zoom blurwhite" id="printableArea"> 
        <a href="schedule.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">
         &times;</a> 	  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> SCHEDULE </h2>
		    <h4 class="w3-center"> <?php echo $_POST['MatchName'] ?> SCHEDULE </h4>
		  </div>

    <p><table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>MATCH No. </th>
		      <th>DATE </th>
		      <th>TIME </th>
	      </tr>
	      <?php
	      	$ID = $_POST['viewSched'];
	      	$sql = "SELECT * FROM `tbl_schedules` WHERE `sched_id`='$ID'";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		       <td><?php echo $row['match_no'] ?></td>
		       <td><?php echo $row['sched_date'] ?></td>   
	      	   <td><?php echo $row['sched_time'] ?></td>	      		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>  

    </div></p>
	 <p class="w3-center w3-padding">
 		<button onclick="window.printDiv('printableArea')" 
		class="<?php echo $btnBW; ?> "> PRINT </button></p>
	 </p>
<?php endif ?>


<?php if (isset($_POST['editSchedules'])): ?>

<div class="w3-modal-content w3-animate-zoom blurwhite"> 
    <a href="schedule.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">
     &times;</a> 	  
	  <div class="w3-container w3-wide">
	    <h2> <?php echo $imgRhom ?> EDIT SCHEDULE </h2>
	  </div>

<?php $ID = $_POST['editSchedules'];
$sql = "SELECT * FROM `tbl_schedules` WHERE `sched_id`='$ID'";
$result = $conn->query($sql);
	if ($result->num_rows > 0): ?>
		<?php while ($row = $result->fetch_assoc()): ?>
		  <div class="w3-row">
			 <div class="w3-third w3-container" style="width: 20%">
			 	   <label class="<?php echo $label ?>"> Match:</label>
				   <label class="w3-large"><b> # <?php echo $row['match_no'] ?></b></label>
				</div>
				<div class="w3-third w3-container" style="width: 40%">
				   
				   	<label class="<?php echo $label ?>"> Date : </label>
		  			<input class="<?php echo $input ?>" name="scheduleData[]" type="date" 
		  			 required value="<?php echo $row['sched_date'] ?>" >
				</div>
				<div class="w3-third w3-container" style="width: 40%">
				   	<label class="<?php echo $label ?>"> Time : </label>
		  			<input class="<?php echo $input ?>" name="scheduleData[]" type="time" 
		  			 required value="<?php echo $row['sched_time'] ?>" > </p>
			  </div>
			</div>	
			
			
		<?php endwhile ?>		      	
	<?php endif ?><div class="w3-center">
	<button name="update_schedules" type="submit" 
     class="<?php echo $btnBW; ?>"> SAVE SCHEDULE </button></div><br>
</div>
<?php endif ?>


<!-- Modal for bracket  -->
<?php if (isset($_POST['printMatch'])):?>
	
	<?php
	$bracketVar=array();
	$ID = $_POST['printMatch'];
	$sql = "SELECT * FROM `tbl_match_res`,`tbl_match` 
	        WHERE tbl_match.match_id = '$ID' 
	        AND tbl_match_res.match_id = tbl_match.match_id"; 
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
				//echo BracketVar("T2",$row['bracket_no'],$row['bracket_house']);
			$bracketVar[$row['bracket_no']] = $row['bracket_house'];
			$match_name = $row['match_category']." ".$row['match_division'].
						  " DIVISION"." ".$row['match_year'];
			$match_id = $row['match_id'];
			$genderDiv = GenderDivision($row['match_division']);


		}
	}	
	//print_r($bracketVar);
?>

   <div class="w3-mobile"> <!-- For PRINTING MATCH RESULTS -->
    
	  <div class="w3-container w3-wide">
	    <h2><?php echo $imgRhom ?> MATCH BRACKET  <label class="w3-right">
	    	<a href="reports.php" class="w3-button w3-hover-dark-gray w3-black">&times;</a> 
	    </label></h2>

	  </div>
	  <form class="w3-container" action="server.php" method="post" id="cat_form">

	  <div class="w3-container" style="overflow-x: auto" >
	  <div id="printableArea">
	  	  <p class="w3-white w3-large w3-center w3-panel w3-text-black w3-padding">
	  	  <img src="Images/aclc.jpg" style="width: 170px"><br>
	  	  <label class="w3-left"><?php echo $match_name?> 
	      <br>MATCH ID: <?php echo $match_id ?></label>
	  	   </p>
	     
	    <div class="" style="background-image: url('Images/eliminationbackground.png');
	     background-repeat: no-repeat; min-width: 1041px;min-height: 581px;" >

			<!-- first row -->
			  <div class="w3-padding w3-container" 
			  style="height: 90px; width: 120px; margin-top:40px;">
			  	  <!-- T2 -->
				 <?php buttonBracket('T2',$bracketVar['T2'],'41px','105px','11px','4px') ?>  	
			 	 <!-- T3 -->
			 	 <?php buttonBracket('T3',$bracketVar['T3'],'41px','105px','0px','4px') ?>

			 </div>
			 
			 <div class="w3-padding w3-container " 
			 style="height: 100px; width: 113px; margin-top:42px;margin-left :4px">
			 	 <!-- T4 -->
				 <?php buttonBracket('T4',$bracketVar['T4'],'40px','105px','auto','auto') ?>
				 <!-- T5 -->
				 <?php buttonBracket('T5',$bracketVar['T5'],'41px','105px','auto','auto') ?>
			 
			 </div>

			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
			  	  <!-- T6 -->
			  	  <?php buttonBracket('T6',$bracketVar['T6'],'40px','105px','auto','auto') ?>  
			 	  <!-- T7 -->
				  <?php buttonBracket('T7',$bracketVar['T7'],'41px','105px','auto','auto') ?>
			    </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
				 <!-- L1 -->
				 <?php buttonBracket('L1',$bracketVar['L1'],'40px','105px','auto','auto') ?> 
			     <!-- L2 -->
			     <?php buttonBracket('L2',$bracketVar['L2'],'40px','105px','auto','auto') ?> 
			   </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;;margin-left :4px">
			  <!-- L3 -->
			  <?php buttonBracket('L3',$bracketVar['L3'],'40px','105px','auto','auto') ?>    
			  <!-- L4 -->
			  <?php buttonBracket('L4',$bracketVar['L4'],'40px','105px','auto','auto') ?>
			 </div>
			   <!--end -->


			<!-- second bracket -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:-600px; margin-left: 207px;">
			    <!--T1 -->
				<?php buttonBracket('T1',$bracketVar['T1'],'40px','105px','auto','auto') ?>  
			    <!--W1 -->
				<?php buttonBracket('W1',$bracketVar['W1'],'41px','105px','auto','auto') ?>
			 </div>

			 <div class="w3-padding w3-container" 
			 style=" height:228px ; width: 113px; margin-left: 207px;">
			 	<!--W2 -->
			 	<?php buttonBracket('W2',$bracketVar['W2'],'41px','105px','60px','auto') ?>
			 	<!--W3 -->
			 	<?php buttonBracket('W3',$bracketVar['W3'],'41px','105px','79px','auto') ?>
			 </div>

			<div class="w3-padding w3-container"
			 style=" height:228px ; width: 113px; margin-left: 207px;">
				<!--W5 -->
				<?php buttonBracket('W5',$bracketVar['W5'],'41px','105px','72px','auto') ?>
				<!--W6 -->
				<?php buttonBracket('W6',$bracketVar['W6'],'41px','105px','79px','auto') ?>
				</div>
			<!-- end -->

			<!-- 3rd bracket -->
			<div class="w3-padding w3-container" 
			style=" height:240px ; width: 113px; margin-left: 407px; margin-top:-529px;">
			   <!--W4 -->
			   <?php buttonBracket('W4',$bracketVar['W4'],'41px','105px','-7px','auto') ?>
			   <!--W7 -->
			   <?php buttonBracket('W7',$bracketVar['W7'],'41px','105px','159px','auto') ?>
			 </div>

			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:153px; margin-left: 407px;">
				<!--L7 -->
				<?php buttonBracket('L7',$bracketVar['L7'],'41px','105px','auto','auto') ?> 
				<!--W8 -->
				<?php buttonBracket('W8',$bracketVar['W8'],'41px','105px','auto','auto') ?>
			 </div>

			<!-- end-->

			<!-- 4th bracket -->
			<div class="w3-padding w3-container" 
			 style=" height:240px ; width: 113px; margin-left: 614px; margin-top:-393px;">
			 <!--W9 -->
			 <?php buttonBracket('W9',$bracketVar['W9'],'41px','101px','-7px','auto') ?>
			 <!--W11 -->
			 <?php buttonBracket('W11',$bracketVar['W11'],'41px','105px','139px','auto') ?>
			 </div>

			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin-top:33px; margin-left: 614px;">
			  <!--L9 -->
			  <?php buttonBracket('L9',$bracketVar['L9'],'41px','100px','auto','auto') ?>
			  <!--W10 -->
			  <?php buttonBracket('W10',$bracketVar['W10'],'41px','100px','auto','auto') ?>	
			</div>

			<!-- end -->

			<!-- 5th bracket -->
			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin:auto; margin-top:-330px; margin-left: 735px;">
			  <!--W9 -->
  			  <?php buttonBracket('W9',$bracketVar['W9'],'41px','98px','auto','auto') ?>	  
			  <!--W12 -->
  			  <?php buttonBracket('W12',$bracketVar['W12'],'41px','98px','auto','auto') ?>
			</div>

			<!-- end -->

			<!--CHAMPION :) W13-->
			<?php buttonBracket('W13',$bracketVar['W13'],'41px','105px','-130px','951px') ?>
			 </div>
			<!-- end -->
	  </form>
  </div>
     </div><!-- print wrap -->
   </div><!-- Modal for bracket  -->
<br><br>

   	<div class="w3-container w3-card-4 w3-margin" id="printResults">
  	  <p class="w3-white w3-large w3-center w3-panel w3-text-black w3-padding">
  	  <img src="Images/aclc.jpg" style="width: 170px"><br>
  	  <label class="w3-left"><?php echo $match_name?> 
      <br>MATCH ID: <?php echo $match_id ?></label></p>

	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>CHAMPION </th>
		      <th>SECOND PLACE</th>
		      <th>THIRD PLACE</th>
	      </tr>
	      <tr class="<?php echo $trhead ?>">
		      <td class="<?php echo colorbox($bracketVar['W13']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W13'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['W9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W9'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['L9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['L9'] ?></td>
	      </tr>
	  </table><br>
	</div>
<br><br>
	<div class="w3-container" id="printPlayers">
  	  <p class="w3-white w3-large w3-center w3-panel w3-text-black w3-padding">
  	  <img src="Images/aclc.jpg" style="width: 170px"><br>
  	  <label class="w3-left"><?php echo $match_name?> 
      <br>MATCH ID: <?php echo $match_id ?></label></p>
      
	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>HOUSE </th>
		      <th>PLAYER </th>
		      <th>  </th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_match`,`tbl_player` WHERE tbl_match.match_id = '$ID' AND tbl_match.match_category = tbl_player.play_category AND tbl_player.play_gender ='$genderDiv' AND tbl_player.play_status ='SELECTED' ORDER BY tbl_player.play_house ASC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		      <td class="">
		      	<label class="<?php echo colorboxPlayer($row['play_house']) ?>">
		      	  <?php echo $row['play_house'] ?></label>
		      </td>
		      
		      <td> <?php echo $row['play_ls'].", ".$row['play_fn'] ?> </td>
		      	  
		      	 <td>
		      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		</table></p> 
	</div>
	 <div class="w3-center w3-padding">
 		<button onclick="window.printDiv('printableArea')" 
		class="<?php echo $btnBW; ?> "> PRINT MATCH BRACKET </button>
		 		<button onclick="window.printDiv('printPlayers')" 
		class="<?php echo $btnBW; ?> "> PRINT PLAYERS </button>
		 		<button onclick="window.printDiv('printResults')" 
		class="<?php echo $btnBW; ?> "> PRINT RESULTS </button>
	 </div><br>
<?php endif ?>