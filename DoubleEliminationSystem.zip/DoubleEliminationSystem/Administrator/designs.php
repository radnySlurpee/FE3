<?php 

//OOP concept
$buttonDG = "w3-button w3-text-aqua w3-wide w3-round w3-hover-pink w3-hover-text-black w3-border w3-border-aqua";
$buttonDGA = "w3-button w3-text-aqua w3-wide w3-round-xlarge w3-hover-cyan w3-hover-text-black  w3-border w3-border-aqua";
$inputBC ="w3-input w3-border w3-border-aqua w3-black w3-text-aqua w3-round-small"; 
$SelectBC ="w3-select w3-border w3-border-black w3-black w3-text-black w3-round"; 
$containerLG = "w3-container w3-padding-small";
$containerDGA = "w3-text-black w3-wide w3-padding";
$containerTabDGA = "w3-bar w3-text-black w3-round-large w3-padding-16";
$searchContainer = "w3-text-black w3-wide w3-padding w3-round-xxlarge  w3-round-large ";
$headerDGA = "w3-text-black w3-wide w3-padding-small w3-center";
$navHeader2="w3-button w3-hover-black w3-hover-text-black w3-small w3-black w3-text-black";
$modSpan = "w3-button w3-display-topright w3-text-cyan w3-hover-black w3-hover-text-black";


//Black And white
$SearchBox="w3-input w3-border w3-border-black w3-text-black w3-round-xlarge";
$table = "w3-table w3-border w3-border-black w3-text-black w3-white w3-card-4";
$tr = "w3-border w3-border-black w3-hover-gray w3-medium w3-animate-zoom";
$btnBW = "w3-button w3-text-black w3-wide w3-round-xlarge w3-hover-black w3-hover-text-white  w3-border w3-border-black w3-white w3-opacity-min";
$btnAct = "w3-button w3-text-black w3-wide w3-round-large w3-hover-white w3-hover-text-white";
$input="w3-input w3-white w3-text-black w3-border w3-border-black w3-hover-light-gray";
$label = "w3-black w3-padding-small w3-small";
$headerBW="fontBarlow w3-padding w3-text-black w3-center";
$divBW="w3-white";
$trhead="w3-black w3-text-white w3-border w3-border-black fontBarlow";
$spanBW="w3-button w3-display-topright w3-hover-dark-gray w3-black";
$navHeader="w3-button w3-hover-black w3-hover-text-white w3-white w3-center";


//images
$imgRhom = '<img src="Images/rhom.png" width="43px" class="w3-animate-zoom">';
$imgArrow = '<img src="Images/arrowSelect.png" width="34px" class="imghov">';
$imgPass = '<img src="Images/pass.png" width="44px">';
$imgHome = '<img src="Images/home1.png" width="24px">';
$imgReps = '<img src="Images/report.png" width="24px">';
$imgUsers = '<img src="Images/users.png" width="24px">';
$imgPlayer = '<img src="Images/player.png" width="24px">';
$imgMatch = '<img src="Images/match.png" width="24px">';
$imgSched = '<img src="Images/schedule.png" width="24px">';
$imgCat = '<img src="Images/category.png" width="24px">';
$imgLogout = '<img src="Images/quit.png" width="24px">';
$imgView = '<img src="images/view.png" width="24px">';
$imgEdit = '<img src="images/editB.png" width="24px">';
$imgReturn = '<img src="images/returnbook.png" width="26">';
$imgSkull = '<img src="images/skull.png" width="100">';
$imgDel='<img src="images/delete.png" width="22px">';
$imgBracketEdit = '<img src="images/editBracket.png" width="24px">';
$imgEditSched = '<img src="images/quick_edit.png" width="24px">';
$imgEditSchedule = '<img src="images/edit_sched.png" width="24px">';

function genderBased($gen){

	if ($gen == "FEMALE") {
		return "WOMEN  DIVISION";
	}else{
		return "MEN  DIVISION";
	}
}
function colorbox($color){

  $border = 'w3-padding-small w3-border w3-border-white';

  if ($color=="VIERRDY") {
    return 'w3-green w3-small '.$border;
  }elseif ($color=="ROXXO"){
     return 'w3-red w3-small '.$border;
  }elseif ($color=="CAHEL"){
     return 'w3-orange w3-small '.$border;
  }elseif ($color=="AZUL"){
     return 'w3-blue w3-small '.$border;
  }elseif ($color=="GIALLIO"){
     return 'w3-yellow w3-small '.$border;  
  }elseif ($color=="BLACK MAMBA"){
     return 'w3-black w3-tiny '.$border;
  }elseif ($color=="WHITE SCORPIONS"){
     return 'w3-white w3-tiny '.$border;        
  }else{
    return 'w3-gray w3-tiny '.$border;
  }

}

function colorboxPlayer($color){

  $border = 'w3-padding-small w3-small w3-border w3-border-white';

  if ($color=="VIERRDY") {
    return 'w3-green '.$border;
  }elseif ($color=="ROXXO"){
     return 'w3-red '.$border;
  }elseif ($color=="CAHEL"){
     return 'w3-orange '.$border;
  }elseif ($color=="AZUL"){
     return 'w3-blue '.$border;
  }elseif ($color=="GIALLIO"){
     return 'w3-yellow '.$border;  
  }elseif ($color=="BLACK MAMBA"){
     return 'w3-black '.$border;
  }elseif ($color=="WHITE SCORPIONS"){
     return 'w3-white'.$border;        
  }else{
    return 'w3-gray '.$border;
  }

}
?>
