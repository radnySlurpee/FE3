<p class="w3-panel w3-medium w3-center">
<label class="w3-black w3-padding w3-border w3-border-black">Hello: </label>
<label class="w3-white w3-padding w3-border w3-border-black">Administrator</label>
</p>
  <p class="w3-panel w3-center">

     	<p class="w3-panel w3-center w3-text-black">
  		<a href="index.php" class="<?php echo $navHeader ?>">HOME<br>
        <label class="w3-text-white">{<?php echo $imgHome ?>}</label></a>
  		<a href="player.php" class="<?php echo $navHeader ?>">PLAYERS<br>
        <label class="w3-text-white">{<?php echo $imgPlayer ?>}</label></a>
  		<a href="match.php" class="<?php echo $navHeader ?>">MATCH<br>
        <label class="w3-text-white">{<?php echo $imgMatch ?>}</label></a>
      <a href="schedule.php" class="<?php echo $navHeader ?>">SCHEDULE<br>
        <label class="w3-text-white">{<?php echo $imgSched ?>}</label></a><br>
  		<a href="category.php" class="<?php echo $navHeader ?>">CATEGORY<br>
        <label class="w3-text-white">{<?php echo $imgCat ?>}</label></a>
      <a href="user.php" class="<?php echo $navHeader ?>">USERS<br>
        <label class="w3-text-white">{<?php echo $imgUsers ?>}</label></a>
  		<a href="reports.php" class="<?php echo $navHeader ?>">REPORTS<br> 
        <label class="w3-text-white">{<?php echo $imgReps ?>}</label></a> 
	   </p>


