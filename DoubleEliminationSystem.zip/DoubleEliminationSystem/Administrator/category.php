<?php include "header.php" ?>

<div class="<?php echo $divBW ?>">
	<h1 class="<?php echo $headerBW ?>">
	 <?php echo $imgRhom ?> GAME CATEGORY INFORMATION </h1>
</div>
 
 <div class="w3-row" style="min-width: 500px;">

  <div class="w3-half w3-container">
	<p class="w3-panel">
	<input class="<?php echo $SearchBox ?>" placeholder="Search.." type="text" name="search" id="inputSearch" onkeyup="searcher()">

		<?php include 'menu.php'; ?>
		<?php include "insert_modal.php"; ?>
  </p>
  </div>

  <div class="w3-half w3-container w3-animate-zoom">

	<h6 class="w3-black w3-center"> 
		<label class="w3-white w3-padding-small"> {} Commands : </label>
	</h6>
	<p class="w3-panel w3-center">
		<button onclick="document.getElementById('add_cat').style.display='block'" class="<?php echo $btnBW; ?>"> + CATEGORY </button>
	</p>

   <p><table class="<?php echo $table ?>" id="outputSearch">
		  <tr class="<?php echo $trhead ?>">
		      <th>CATEGORY NAME </th>
		      <th>MAX PLAYER </th>
		      <th>ACTION </th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_category` ORDER BY category_name DESC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?> w3-large">
		      <td>
		      	 <?php echo $row['category_name'] ?>
		      </td>
		      <td> 
		      	<?php echo $row['cat_max_player'] ?>
		      	 
		      </td>
		      	  
			      	 <td>
				   		<form method="post" action="update_modal.php">
				      	 <button type="submit" value="<?php echo $row['category_name'] ?>" name="editCat" class="<?php echo $btnAct; ?>" ><?php echo $imgEdit ?></button>
			      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p> 
  </div>

</div>

<?php include "footer.php" ?>