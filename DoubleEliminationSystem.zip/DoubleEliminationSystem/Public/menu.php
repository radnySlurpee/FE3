<p class="w3-panel w3-medium w3-center">
<label class="w3-black w3-padding w3-border w3-border-black"> PUBLIC: </label>
<label class="w3-white w3-padding w3-border w3-border-black"> ACCESS </label>
</p>
  <p class="w3-panel w3-center">

     	<p class="w3-panel w3-center w3-text-black w3-large">
  		<a href="index.php" class="<?php echo $navHeader ?>">HOME<br>
        <label class="w3-text-white">{<?php echo $imgHome ?>}</label></a>
         <a href="match.php" class="<?php echo $navHeader ?>">MATCH LIST<br>
        <label class="w3-text-white">{<?php echo $imgList ?>}</label></a>
         <a href="login.php" class="<?php echo $navHeader ?>">LOGIN<br>
        <label class="w3-text-white">{<?php echo $imgLogin ?>}</label></a>
	   </p>

<p class="w3-center w3-panel"><img src="Images/pub.png" width="100px" class="w3-animate-zoom"></p>

