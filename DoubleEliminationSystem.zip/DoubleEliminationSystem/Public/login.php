<?php include "header.php" ?>

<div class="<?php echo $divBW ?>">
	<h1 class="<?php echo $headerBW ?>">
	 <?php echo $imgRhom ?> LOGIN </h1>
</div>
 
 <div class="w3-row" style="min-width: 500px;">

  <div class="w3-half w3-container">
	<p class="w3-panel">
		<?php include 'menu.php'; ?>
  </p>
  	
  </div>

  <div class="w3-half w3-container w3-animate-zoom">

	<h6 class="w3-black w3-center"> 
		<label class="w3-white w3-padding-small"> { LOGIN } </label></h6>
	<p class="w3-panel w3-center w3-padding">
     		  
		  <form class="w3-container" action="" method="post" >
		              
		    <div class="w3-row-padding">
		    	<p><label class="<?php echo $label ?>"> Username: </label>
		  			<input class="<?php echo $input ?>" name="user" type="text" required></p>

		  		<p><label class="<?php echo $label ?>"> Password: </label>
		  			<input class="<?php echo $input ?>" name="pass" type="password" required></p>
			</div>

		    <p class="w3-center">
		    <button name="login" type="submit" class="<?php echo $btnBW; ?>"> LOGIN </button></p>
		  </form>
	</p>
   
  </div>

</div>

<?php include "footer.php" ?>