-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2018 at 02:03 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `double_elimination_db`
--
CREATE DATABASE IF NOT EXISTS `double_elimination_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `double_elimination_db`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_name` varchar(50) NOT NULL,
  `cat_max_player` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_name`, `cat_max_player`) VALUES
('Basket Ball', 7),
('CHESS', 1),
('DOTA 2', 5),
('SCRABBLE', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_house`
--

DROP TABLE IF EXISTS `tbl_house`;
CREATE TABLE IF NOT EXISTS `tbl_house` (
  `house` varchar(50) NOT NULL,
  `house_color` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_house`
--

INSERT INTO `tbl_house` (`house`, `house_color`) VALUES
('BLACK MAMBA', 'black'),
('AZUL', 'blue'),
('VIERRDY', 'green'),
('CAHEL', 'orange'),
('ROXXO', 'red'),
('WHITE SCORPIONS', 'white'),
('GIALLIO', 'yellow');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_match`
--

DROP TABLE IF EXISTS `tbl_match`;
CREATE TABLE IF NOT EXISTS `tbl_match` (
  `match_id` int(11) NOT NULL,
  `match_category` varchar(50) NOT NULL,
  `match_division` enum('MENS','WOMENS') NOT NULL,
  `match_year` year(4) NOT NULL,
  `match_sched_id` int(11) NOT NULL,
  `match_arb_id` int(11) NOT NULL,
  `match_status` enum('LOCK','UNLOCK','SHOW') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_match`
--

INSERT INTO `tbl_match` (`match_id`, `match_category`, `match_division`, `match_year`, `match_sched_id`, `match_arb_id`, `match_status`) VALUES
(1, 'DOTA 2', 'MENS', 2017, 1, 2, 'UNLOCK'),
(2, 'CHESS', 'MENS', 2018, 2, 3, 'UNLOCK');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_match_res`
--

DROP TABLE IF EXISTS `tbl_match_res`;
CREATE TABLE IF NOT EXISTS `tbl_match_res` (
  `result_id` int(11) NOT NULL,
  `match_id` int(11) NOT NULL,
  `bracket_no` varchar(3) NOT NULL,
  `bracket_house` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_match_res`
--

INSERT INTO `tbl_match_res` (`result_id`, `match_id`, `bracket_no`, `bracket_house`) VALUES
(1, 1, 'T1', 'AZUL'),
(2, 1, 'T2', 'ROXXO'),
(3, 1, 'T3', 'BLACK MAMBA'),
(4, 1, 'T4', 'WHITE SCORPIONS'),
(5, 1, 'T5', 'VIERRDY'),
(6, 1, 'T6', 'GIALLIO'),
(7, 1, 'T7', 'CAHEL'),
(8, 1, 'W1', 'ROXXO'),
(9, 1, 'W2', 'VIERRDY'),
(10, 1, 'W3', 'CAHEL'),
(11, 1, 'W4', 'AZUL'),
(12, 1, 'W5', 'BLACK MAMBA'),
(13, 1, 'W6', 'ROXXO'),
(14, 1, 'W7', 'CAHEL'),
(15, 1, 'W8', 'ROXXO'),
(16, 1, 'W9', 'AZUL'),
(17, 1, 'W10', 'ROXXO'),
(18, 1, 'W11', 'ROXXO'),
(19, 1, 'W12', 'ROXXO'),
(20, 1, 'W13', 'ROXXO'),
(21, 1, 'L1', 'BLACK MAMBA'),
(22, 1, 'L2', 'WHITE SCORPIONS'),
(23, 1, 'L3', 'GIALLIO'),
(24, 1, 'L4', 'ROXXO'),
(25, 1, 'L7', 'VIERRDY'),
(27, 1, 'L9', 'CAHEL'),
(30, 2, 'T1', ''),
(31, 2, 'T2', ''),
(32, 2, 'T3', ''),
(33, 2, 'T4', ''),
(34, 2, 'T5', ''),
(35, 2, 'T6', ''),
(36, 2, 'T7', ''),
(37, 2, 'W1', ''),
(38, 2, 'W2', ''),
(39, 2, 'W3', ''),
(40, 2, 'W4', ''),
(41, 2, 'W5', ''),
(42, 2, 'W6', ''),
(43, 2, 'W7', ''),
(44, 2, 'W8', ''),
(45, 2, 'W9', ''),
(46, 2, 'W10', ''),
(47, 2, 'W11', ''),
(48, 2, 'W12', ''),
(49, 2, 'W13', ''),
(50, 2, 'L1', ''),
(51, 2, 'L2', ''),
(52, 2, 'L3', ''),
(53, 2, 'L4', ''),
(54, 2, 'L7', ''),
(55, 2, 'L9', ''),
(56, 2, 'T1', 'ROXXO'),
(57, 2, 'T2', 'VIERRDY'),
(58, 2, 'T3', 'GIALLIO'),
(59, 2, 'T4', 'AZUL'),
(60, 2, 'T5', 'BLACK MAMBA'),
(61, 2, 'T6', 'CAHEL'),
(62, 2, 'T7', 'WHITE SCORPIONS'),
(63, 2, 'W1', ''),
(64, 2, 'W2', ''),
(65, 2, 'W3', ''),
(66, 2, 'W4', ''),
(67, 2, 'W5', ''),
(68, 2, 'W6', ''),
(69, 2, 'W7', ''),
(70, 2, 'W8', ''),
(71, 2, 'W9', ''),
(72, 2, 'W10', ''),
(73, 2, 'W11', ''),
(74, 2, 'W12', ''),
(75, 2, 'W13', ''),
(76, 2, 'L1', ''),
(77, 2, 'L2', ''),
(78, 2, 'L3', ''),
(79, 2, 'L4', ''),
(80, 2, 'L7', ''),
(81, 2, 'L9', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_player`
--

DROP TABLE IF EXISTS `tbl_player`;
CREATE TABLE IF NOT EXISTS `tbl_player` (
  `player_id` int(11) NOT NULL,
  `play_fn` varchar(50) NOT NULL,
  `play_ls` varchar(50) NOT NULL,
  `play_gender` enum('MALE','FEMALE') NOT NULL,
  `play_house` varchar(50) NOT NULL,
  `play_category` varchar(100) NOT NULL,
  `play_status` enum('SELECTED','RESERVED') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_player`
--

INSERT INTO `tbl_player` (`player_id`, `play_fn`, `play_ls`, `play_gender`, `play_house`, `play_category`, `play_status`) VALUES
(1, 'radny', 'ongtawco', 'MALE', 'VIERRDY', 'DOTA 2', 'SELECTED'),
(2, 'marsh', 'mello', 'MALE', 'ROXXO', 'DOTA 2', 'SELECTED'),
(4, 'Goerge', 'Goodman', 'FEMALE', 'BLACK MAMBA', 'DOTA 2', 'RESERVED'),
(5, 'hiro', 'soonsa', 'MALE', 'WHITE SCORPIONS', 'DOTA 2', 'SELECTED'),
(6, 'Ains Oown', 'Goon', 'MALE', 'CAHEL', 'DOTA 2', 'SELECTED'),
(7, 'henrick', 'son', 'MALE', 'GIALLIO', 'DOTA 2', 'SELECTED'),
(8, 'Hans', 'Zimmer', 'MALE', 'AZUL', 'DOTA 2', 'SELECTED'),
(9, 'mefisto', 'gurazo', 'MALE', 'AZUL', 'DOTA 2', 'SELECTED'),
(10, 'deemo', 'Hart', 'MALE', 'VIERRDY', 'CHESS', 'SELECTED');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sched`
--

DROP TABLE IF EXISTS `tbl_sched`;
CREATE TABLE IF NOT EXISTS `tbl_sched` (
  `sched_id` int(11) NOT NULL,
  `sched_duration` int(11) NOT NULL,
  `sched_date` date NOT NULL,
  `sched_no_days` int(11) NOT NULL,
  `sched_start_time` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sched`
--

INSERT INTO `tbl_sched` (`sched_id`, `sched_duration`, `sched_date`, `sched_no_days`, `sched_start_time`) VALUES
(1, 60, '2018-02-01', 3, '08:00:00'),
(2, 30, '2018-02-02', 5, '10:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedules`
--

DROP TABLE IF EXISTS `tbl_schedules`;
CREATE TABLE IF NOT EXISTS `tbl_schedules` (
  `schedules_id` int(11) NOT NULL,
  `sched_id` int(11) NOT NULL,
  `match_no` varchar(4) NOT NULL,
  `sched_date` date NOT NULL,
  `sched_time` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_schedules`
--

INSERT INTO `tbl_schedules` (`schedules_id`, `sched_id`, `match_no`, `sched_date`, `sched_time`) VALUES
(27, 1, '1', '2018-02-01', '08:00:00'),
(28, 1, '2', '2018-02-01', '09:00:00'),
(29, 1, '3', '2018-02-01', '10:00:00'),
(30, 1, '4', '2018-02-01', '11:00:00'),
(31, 1, '5', '2018-02-01', '12:00:00'),
(32, 1, '6', '2018-02-01', '13:00:00'),
(33, 1, '7', '2018-02-01', '14:00:00'),
(34, 1, '8', '2018-02-01', '15:00:00'),
(35, 1, '9', '2018-02-01', '16:00:00'),
(36, 1, '10', '2018-02-01', '17:00:00'),
(37, 1, '11', '2018-02-01', '18:00:00'),
(38, 1, '12', '2018-02-01', '19:00:00'),
(39, 1, '13', '2018-02-01', '20:00:00'),
(40, 2, '1', '2018-02-01', '09:30:00'),
(41, 2, '2', '2018-02-01', '10:00:00'),
(42, 2, '3', '2018-02-01', '10:30:00'),
(43, 2, '4', '2018-02-01', '11:00:00'),
(44, 2, '5', '2018-02-01', '11:30:00'),
(45, 2, '6', '2018-02-01', '12:00:00'),
(46, 2, '7', '2018-02-01', '12:30:00'),
(47, 2, '8', '2018-02-01', '13:00:00'),
(48, 2, '9', '2018-02-01', '13:30:00'),
(49, 2, '10', '2018-02-01', '14:00:00'),
(50, 2, '11', '2018-02-01', '14:30:00'),
(51, 2, '12', '2018-02-01', '15:00:00'),
(52, 2, '13', '2018-02-01', '15:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `user_type` enum('ARBITER','ADMIN') NOT NULL,
  `user_status` enum('ACTIVE','INACTIVE') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `user_type`, `user_status`) VALUES
(1, 'admin', 'admin', 'ADMIN', 'ACTIVE'),
(2, 'arbiterONE', 'arbiter1', 'ARBITER', 'ACTIVE'),
(3, 'arbiterTWO', 'arbiter2', 'ARBITER', 'INACTIVE'),
(6, 'Arbiter33', 'qwert', 'ARBITER', 'ACTIVE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_name`);

--
-- Indexes for table `tbl_house`
--
ALTER TABLE `tbl_house`
  ADD PRIMARY KEY (`house`),
  ADD UNIQUE KEY `house_color` (`house_color`);

--
-- Indexes for table `tbl_match`
--
ALTER TABLE `tbl_match`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `match_sched_id` (`match_sched_id`),
  ADD KEY `match_arb_id` (`match_arb_id`),
  ADD KEY `match_category` (`match_category`);

--
-- Indexes for table `tbl_match_res`
--
ALTER TABLE `tbl_match_res`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `bracket_house` (`bracket_house`);

--
-- Indexes for table `tbl_player`
--
ALTER TABLE `tbl_player`
  ADD PRIMARY KEY (`player_id`),
  ADD KEY `play_house` (`play_house`),
  ADD KEY `play_category` (`play_category`);

--
-- Indexes for table `tbl_sched`
--
ALTER TABLE `tbl_sched`
  ADD PRIMARY KEY (`sched_id`);

--
-- Indexes for table `tbl_schedules`
--
ALTER TABLE `tbl_schedules`
  ADD PRIMARY KEY (`schedules_id`),
  ADD KEY `sched_id` (`sched_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_match`
--
ALTER TABLE `tbl_match`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_match_res`
--
ALTER TABLE `tbl_match_res`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `tbl_player`
--
ALTER TABLE `tbl_player`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_sched`
--
ALTER TABLE `tbl_sched`
  MODIFY `sched_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_schedules`
--
ALTER TABLE `tbl_schedules`
  MODIFY `schedules_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_match`
--
ALTER TABLE `tbl_match`
  ADD CONSTRAINT `tbl_match_ibfk_1` FOREIGN KEY (`match_category`) REFERENCES `tbl_category` (`category_name`),
  ADD CONSTRAINT `tbl_match_ibfk_2` FOREIGN KEY (`match_sched_id`) REFERENCES `tbl_sched` (`sched_id`),
  ADD CONSTRAINT `tbl_match_ibfk_3` FOREIGN KEY (`match_arb_id`) REFERENCES `tbl_users` (`user_id`);

--
-- Constraints for table `tbl_match_res`
--
ALTER TABLE `tbl_match_res`
  ADD CONSTRAINT `tbl_match_res_ibfk_1` FOREIGN KEY (`match_id`) REFERENCES `tbl_match` (`match_id`);

--
-- Constraints for table `tbl_player`
--
ALTER TABLE `tbl_player`
  ADD CONSTRAINT `tbl_player_ibfk_1` FOREIGN KEY (`play_house`) REFERENCES `tbl_house` (`house`),
  ADD CONSTRAINT `tbl_player_ibfk_2` FOREIGN KEY (`play_category`) REFERENCES `tbl_category` (`category_name`);

--
-- Constraints for table `tbl_schedules`
--
ALTER TABLE `tbl_schedules`
  ADD CONSTRAINT `tbl_schedules_ibfk_1` FOREIGN KEY (`sched_id`) REFERENCES `tbl_sched` (`sched_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
