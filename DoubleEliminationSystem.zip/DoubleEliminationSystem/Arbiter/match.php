<?php include "header.php" ?>

<div class="<?php echo $divBW ?>">
	<h1 class="<?php echo $headerBW ?>">
	 <?php echo $imgRhom ?> ARBITER MODE </h1>
</div>
 
 <div class="w3-row" style="min-width: 500px;">

  <div class="w3-half w3-container">
	<p class="w3-panel">
	<input class="<?php echo $SearchBox ?>" placeholder="Search.." type="text" name="search" id="inputSearch" onkeyup="searcher()">
		<?php include 'menu.php'; ?>
  </p>
  	
  </div>

  <div class="w3-half w3-container w3-animate-zoom">

	<h6 class="w3-black w3-center"> 
		<label class="w3-white w3-padding-small"> { YOUR ASSIGN MATCH } </label></h6>
	<p class="w3-panel w3-center">
	</p>
   <p><table class="<?php echo $table ?>" id="outputSearch">
		  <tr class="<?php echo $trhead ?>">
		      <th>MATCH </th>
		      <th>SCHEDULE </th>
		      <th>BRACKET </th>
	      </tr>
	      
	      <?php
	      	$sql = "SELECT * FROM `tbl_match`
	      			WHERE match_status ='UNLOCK'
	      			ORDER BY match_year ASC ";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		      <td>
		      	 <?php echo $row['match_category']." ".$row['match_division']." DIVISION"."
		      	  ".$row['match_year'] ?><br>
		      	  <label class="w3-black w3-padding-small w3-small">
		      	  	ID: <?php echo $row['match_id'] ?></label>
		      </td>
		      <form method="post" action="update_modal.php">
		      <td> 
		      	<button type="submit" value="<?php echo $row['match_sched_id'] ?>" name="viewSched" 
		      	class="<?php echo $btnAct; ?>" ><?php echo $imgSched ?></button>
	      	    <input type="hidden" name="MatchName" 
			      	 value="<?php echo $row['match_category']." "
			      	 .$row['match_division']." DIVISION"."
	      	  		".$row['match_year'] ?>">
		      </td>
	      	  <td>
			    <button type="submit" value="<?php echo $row['match_id'] ?>" name="editBracket" class="<?php echo $btnAct; ?>" ><?php echo $imgBracketEdit ?></button>
	      	  </td>
	      	 </form>		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p> 
  </div>

</div>

<?php include "footer.php" ?>