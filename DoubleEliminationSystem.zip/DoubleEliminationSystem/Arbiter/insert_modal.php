  
  <div id="add_player" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom blurwhite parallax"> 
        <span onclick="document.getElementById('add_player').style.display='none'" 
        class="<?php echo $spanBW ?>">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> REGISTER PLAYER </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="plyr_form">
		              
		    <div class="w3-row-padding">
		    	<p><label class="<?php echo $label ?>"> First name : </label>
		  			<input class="<?php echo $input ?>" name="fs" type="text" required></p>

		  		<p><label class="<?php echo $label ?>"> Last name : </label>
		  			<input class="<?php echo $input ?>" name="ls" type="text" required></p>

		  		<p><label class="<?php echo $label ?>"> Gender : </label>
		  			<select class="<?php echo $input ?>" name="gen" form="plyr_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="MALE">Male</option>
						<option value="FEMALE">Female</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> House : </label>
		  			<select class="<?php echo $input ?>" name="house" form="plyr_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="AZUL">AZUL</option>
						<option value="CAHEL">CAHEL</option>
						<option value="GIALLIO">GIALLIO</option>
						<option value="ROXXO">ROXXO</option>
						<option value="VIERRDY">VIERRDY</option>
						<option value="BLACK MAMBA">BLACK MAMBA</option>
						<option value="WHITE SCORPIONS">WHITE SCORPIONS</option>
					</select></p>
		  		<p><label class="<?php echo $label ?>"> Game Category : </label>
		  			<select class="<?php echo $input ?>" name="cat" form="plyr_form" required>
					  <option value="" disabled selected>Choose..</option>
				<?php
				$sql = "SELECT * FROM `tbl_category`";
				$result = $conn->query($sql);
				if ($result->num_rows > 0): ?>
				<?php while ($row = $result->fetch_assoc()): ?>
						  <option value="<?php echo $row['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
				<?php endwhile ?>		      	
				<?php endif ?>
					</select></p>

				<p><label class="<?php echo $label ?>"> Status : </label>
		  			<select class="<?php echo $input ?>" name="stats" form="plyr_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="SELECTED">Selected</option>
						<option value="RESERVED">Reserved</option>
					</select></p>

			</div>

		    <p class="w3-center">
		    <button name="insert_player" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>
  </div>



  <div id="add_user" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom blurwhite parallax"> 
        <span onclick="document.getElementById('add_user').style.display='none'" 
        class="<?php echo $spanBW ?>">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> REGISTER USER </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="user_form">
		              
		    <div class="w3-row-padding">
		    	<p><label class="<?php echo $label ?>"> Username: </label>
		  			<input class="<?php echo $input ?>" name="user" type="text" required></p>

		  		<p><label class="<?php echo $label ?>"> Password : </label>
		  			<input class="<?php echo $input ?>" name="pass" type="password" required></p>

		  		<p><label class="<?php echo $label ?>"> TYPE : </label>
		  			<select class="<?php echo $input ?>" name="type" form="user_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="ADMIN">ADMIN</option>
						<option value="ARBITER">ARBITER</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> STATUS : </label>
		  			<select class="<?php echo $input ?>" name="stat" form="user_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="ACTIVE">ACTIVE</option>
						<option value="INACTIVE">INACTIVE</option>
					</select></p>
			</div>

		    <p class="w3-center">
		    <button name="insert_user" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>
  </div>



    <div id="add_cat" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom blurwhite parallax"> 
        <span onclick="document.getElementById('add_cat').style.display='none'" 
        class="<?php echo $spanBW ?>">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> ADDING <br> GAME CATEGORY </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="cat_form">
		              
		    <div class="w3-row-padding">
		    	<p><label class="<?php echo $label ?>"> Category Name : </label>
		  			<input class="<?php echo $input ?>" name="catname" type="text" required></p>

		  		<p><label class="<?php echo $label ?>"> Max no. of Players per houses : </label>
		  			<input class="<?php echo $input ?>" name="nummax" type="number" required></p>
			</div>

		    <p class="w3-center">
		    <button name="insert_cat" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>
  </div>


<div id="add_match" class="w3-modal">
    <div class="w3-modal-content w3-animate-zoom blurwhite"> 
        <span onclick="document.getElementById('add_match').style.display='none'" 
        class="<?php echo $spanBW ?>">&times;</span>		  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> CREATE MATCH </h2>
		  </div>
		  <form class="w3-container" action="server.php" method="post" id="match_form">
		              
		    <div class="w3-row-padding">
		  		<p><label class="<?php echo $label ?>"> Choose a House for the TEAM 1 bracket : </label>
		  			<select class="<?php echo $input ?>" name="house" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="AZUL">AZUL</option>
						<option value="CAHEL">CAHEL</option>
						<option value="GIALLIO">GIALLIO</option>
						<option value="ROXXO">ROXXO</option>
						<option value="VIERRDY">VIERRDY</option>
						<option value="BLACK MAMBA">BLACK MAMBA</option>
						<option value="WHITE SCORPIONS">WHITE SCORPIONS</option>
					</select></p>
		  		<p><label class="<?php echo $label ?>"> Game Category : </label>
		  			<select class="<?php echo $input ?>" name="cat" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
				<?php
				$sql = "SELECT * FROM `tbl_category`";
				$result = $conn->query($sql);
				if ($result->num_rows > 0): ?>
				<?php while ($row = $result->fetch_assoc()): ?>
						  <option value="<?php echo $row['category_name'] ?>"> <?php echo $row['category_name'] ?> </option>
				<?php endwhile ?>		      	
				<?php endif ?>
					</select></p>

				<p><label class="<?php echo $label ?>"> Gender Division : </label>
		  			<select class="<?php echo $input ?>" name="gendiv" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="MENS">MENS</option>
						<option value="WOMENS">WOMENS</option>
					</select></p>

		  		<p><label class="<?php echo $label ?>"> Year : </label>
		  			<input class="<?php echo $input ?>" name="yr" type="number" required min="2010" 
		  			placeholder="0000" ></p>

				<p><label class="<?php echo $label ?>"> Arbiter Assign : </label>
		  			<select class="<?php echo $input ?>" name="gendiv" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>

					<?php
					$sql = "SELECT * FROM `tbl_users` WHERE user_type='ARBITER'";
					$result = $conn->query($sql);
					if ($result->num_rows > 0): ?>
					<?php while ($row = $result->fetch_assoc()): ?>
					  <option value="<?php echo $row['user_id'] ?>"> 
					  <?php echo $row['username'] ?> </option>
					<?php endwhile ?>		      	
					<?php endif ?>

					</select></p>

				<p><label class="<?php echo $label ?>"> Match Status : </label>
		  			<select class="<?php echo $input ?>" name="mstat" form="match_form" required>
					  <option value="" disabled selected>Choose..</option>
						<option value="LOCK">LOCK</option>
						<option value="UNLOCK">UNLOCK</option>
					</select></p>
					<br>
				
				<h4 class="w3-black"> {} Match Schedule </h4>

		  		<p><label class="<?php echo $label ?>"> Starting Date : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="date" required></p>
		  		<p><label class="<?php echo $label ?>"> Starting Time : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="time" required></p>
		  		<p><label class="<?php echo $label ?>"> No. of Days : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="number" required min="1"></p>
		  		<p><label class="<?php echo $label ?>"> Duration per Match (minutes) : </label>
		  			<input class="<?php echo $input ?>" name="sched" type="number" required min="10"></p>
		  		</p>
			
			</div>
		    <p class="w3-center">
		    <button name="insert_user" type="submit" class="<?php echo $btnBW; ?>"> SAVE </button></p>
		  </form>
    </div>
  </div>
