<p class="w3-panel w3-medium w3-center">
<label class="w3-black w3-padding w3-border w3-border-black">Hello: </label>
<label class="w3-white w3-padding w3-border w3-border-black">Arbiter</label>
</p>
  <p class="w3-panel w3-center">

     	<p class="w3-panel w3-center w3-text-black">
  		<a href="index.php" class="<?php echo $navHeader ?>">HOME<br>
        <label class="w3-text-white">{<?php echo $imgHome ?>}</label></a>
  		<a href="match.php" class="<?php echo $navHeader ?>">MATCH<br>
        <label class="w3-text-white">{<?php echo $imgMatch ?>}</label></a>
      
	   </p>
<p class="w3-center w3-panel"><img src="Images/owl.png" width="100px" class="w3-animate-zoom"></p>

