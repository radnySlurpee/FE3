<?php include 'header.php'; ?>
<br>
<?php 

	function GenderDivision($gen){
		if ($gen == "WOMENS") {
			return 'FEMALE';
		}else{
			return 'MALE';
		}
	}

	function buttonBracket($Name,$bracketNumber,$Height,$Width,$top,$left){

		if ($bracketNumber == "") {
			$readonly = "visibility:hidden";
		}else{
			$readonly = "";
		}

		echo '<button class="w3-button w3-border w3-border-black '.colorbox($bracketNumber).'" ';
		echo 'name="'.$Name.'" value="'.$bracketNumber.'"';
		echo 'style="height: '.$Height.'; width: '.$Width.'; 
		      margin-top :'.$top.';margin-left :'.$left.';
		      '.$readonly.' ">';
		echo $bracketNumber;
		echo '</button>';
	}
 ?>

<!-- Modal for bracket  -->
<?php if (isset($_POST['editBracket'])):?>
	
	<?php
	$bracketVar=array();
	$ID = $_POST['editBracket'];
	$sql = "SELECT * FROM `tbl_match_res`,`tbl_match` 
	        WHERE tbl_match.match_id = '$ID' 
	        AND tbl_match_res.match_id = tbl_match.match_id"; 
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
				//echo BracketVar("T2",$row['bracket_no'],$row['bracket_house']);
			$bracketVar[$row['bracket_no']] = $row['bracket_house'];
			$match_name = $row['match_category']." ".$row['match_division'].
						  " DIVISION"." ".$row['match_year'];
			$match_id = $row['match_id'];
			$genderDiv = GenderDivision($row['match_division']);


		}
	}	
	//print_r($bracketVar);
?>

   <div class="w3-mobile"> 
    
	  <div class="w3-container w3-wide">
	    <h2><?php echo $imgRhom ?> MATCH BRACKET  <label class="w3-right">
	    	<a href="match.php" class="w3-button w3-hover-dark-gray w3-black">&times;</a> 
	    </label></h2>
	    <p class="w3-black w3-large w3-panel w3-text-white w3-padding"> <?php echo $match_name?> 
	    <br>MATCH ID: <?php echo $match_id ?></p>
	  </div>
	  <form class="w3-container" action="server.php" method="post" id="cat_form">
	  <div class="w3-container" style="overflow-x: auto">
	    <div class="" style="background-image: url('Images/eliminationbackground.png');
	     background-repeat: no-repeat; min-width: 1041px;min-height: 581px;">

			<!-- first row -->
			  <div class="w3-padding w3-container" 
			  style="height: 90px; width: 120px; margin-top:40px;">
			  	  <!-- T2 -->
				 <?php buttonBracket('T2',$bracketVar['T2'],'41px','105px','11px','4px') ?>  	
			 	 <!-- T3 -->
			 	 <?php buttonBracket('T3',$bracketVar['T3'],'41px','105px','0px','4px') ?>

			 </div>
			 
			 <div class="w3-padding w3-container " 
			 style="height: 100px; width: 113px; margin-top:42px;margin-left :4px">
			 	 <!-- T4 -->
				 <?php buttonBracket('T4',$bracketVar['T4'],'40px','105px','auto','auto') ?>
				 <!-- T5 -->
				 <?php buttonBracket('T5',$bracketVar['T5'],'41px','105px','auto','auto') ?>
			 
			 </div>

			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
			  	  <!-- T6 -->
			  	  <?php buttonBracket('T6',$bracketVar['T6'],'40px','105px','auto','auto') ?>  
			 	  <!-- T7 -->
				  <?php buttonBracket('T7',$bracketVar['T7'],'41px','105px','auto','auto') ?>
			    </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:20px;margin-left :4px">
				 <!-- L1 -->
				 <?php buttonBracket('L1',$bracketVar['L1'],'40px','105px','auto','auto') ?> 
			     <!-- L2 -->
			     <?php buttonBracket('L2',$bracketVar['L2'],'40px','105px','auto','auto') ?> 
			   </div>

			   <!-- first lose -->
			  <div class="w3-padding w3-container"
			  style="height: 100px; width: 113px; margin-top:20px;;margin-left :4px">
			  <!-- L3 -->
			  <?php buttonBracket('L3',$bracketVar['L3'],'40px','105px','auto','auto') ?>    
			  <!-- L4 -->
			  <?php buttonBracket('L4',$bracketVar['L4'],'40px','105px','auto','auto') ?>
			 </div>
			   <!--end -->


			<!-- second bracket -->
			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:-600px; margin-left: 207px;">
			    <!--T1 -->
				<?php buttonBracket('T1',$bracketVar['T1'],'40px','105px','auto','auto') ?>  
			    <!--W1 -->
				<?php buttonBracket('W1',$bracketVar['W1'],'41px','105px','auto','auto') ?>
			 </div>

			 <div class="w3-padding w3-container" 
			 style=" height:228px ; width: 113px; margin-left: 207px;">
			 	<!--W2 -->
			 	<?php buttonBracket('W2',$bracketVar['W2'],'41px','105px','60px','auto') ?>
			 	<!--W3 -->
			 	<?php buttonBracket('W3',$bracketVar['W3'],'41px','105px','79px','auto') ?>
			 </div>

			<div class="w3-padding w3-container"
			 style=" height:228px ; width: 113px; margin-left: 207px;">
				<!--W5 -->
				<?php buttonBracket('W5',$bracketVar['W5'],'41px','105px','72px','auto') ?>
				<!--W6 -->
				<?php buttonBracket('W6',$bracketVar['W6'],'41px','105px','79px','auto') ?>
				</div>
			<!-- end -->

			<!-- 3rd bracket -->
			<div class="w3-padding w3-container" 
			style=" height:240px ; width: 113px; margin-left: 407px; margin-top:-529px;">
			   <!--W4 -->
			   <?php buttonBracket('W4',$bracketVar['W4'],'41px','105px','-7px','auto') ?>
			   <!--W7 -->
			   <?php buttonBracket('W7',$bracketVar['W7'],'41px','105px','159px','auto') ?>
			 </div>

			  <div class="w3-padding w3-container" 
			  style="height: 100px; width: 113px; margin-top:153px; margin-left: 407px;">
				<!--L7 -->
				<?php buttonBracket('L7',$bracketVar['L7'],'41px','105px','auto','auto') ?> 
				<!--W8 -->
				<?php buttonBracket('W8',$bracketVar['W8'],'41px','105px','auto','auto') ?>
			 </div>

			<!-- end-->

			<!-- 4th bracket -->
			<div class="w3-padding w3-container" 
			 style=" height:240px ; width: 113px; margin-left: 614px; margin-top:-393px;">
			 <!--W9 -->
			 <?php buttonBracket('W9',$bracketVar['W9'],'41px','101px','-7px','auto') ?>
			 <!--W11 -->
			 <?php buttonBracket('W11',$bracketVar['W11'],'41px','105px','139px','auto') ?>
			 </div>

			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin-top:33px; margin-left: 614px;">
			  <!--L9 -->
			  <?php buttonBracket('L9',$bracketVar['L9'],'41px','100px','auto','auto') ?>
			  <!--W10 -->
			  <?php buttonBracket('W10',$bracketVar['W10'],'41px','100px','auto','auto') ?>	
			</div>

			<!-- end -->

			<!-- 5th bracket -->
			<div class="w3-padding w3-container" 
			style="height: 100px; width: 113px; margin:auto; margin-top:-330px; margin-left: 735px;">
			  <!--W9 -->
  			  <?php buttonBracket('W9',$bracketVar['W9'],'41px','98px','auto','auto') ?>	  
			  <!--W12 -->
  			  <?php buttonBracket('W12',$bracketVar['W12'],'41px','98px','auto','auto') ?>
			</div>

			<!-- end -->

			<!--CHAMPION :) W13-->
			<?php buttonBracket('W13',$bracketVar['W13'],'41px','105px','-130px','951px') ?>
			 </div>
			<!-- end -->
	  </form>
  </div>
   </div><!-- Modal for bracket  -->
<br><br>

   	<div class="w3-container w3-card-4">
	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>CHAMPION </th>
		      <th>SECOND PLACE</th>
		      <th>THIRD PLACE</th>
	      </tr>
	      <tr class="<?php echo $trhead ?>">
		      <td class="<?php echo colorbox($bracketVar['W13']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W13'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['W9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['W9'] ?></td>
		      <td class="<?php echo colorbox($bracketVar['L9']) ?> w3-large w3-center"> 
		      	<?php echo $bracketVar['L9'] ?></td>
	      </tr>
	  </table>
	</div>
<br><br>
	<div class="w3-container w3-card-4">
	   <table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>HOUSE </th>
		      <th>PLAYER </th>
		      <th>  </th>
	      </tr>
	      <?php
	      	$sql = "SELECT * FROM `tbl_match`,`tbl_player` WHERE tbl_match.match_id = '$ID' AND tbl_match.match_category = tbl_player.play_category AND tbl_player.play_gender ='$genderDiv' AND tbl_player.play_status ='SELECTED' ORDER BY tbl_player.play_house ASC";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		      <td class="">
		      	<label class="<?php echo colorboxPlayer($row['play_house']) ?>">
		      	  <?php echo $row['play_house'] ?></label>
		      </td>
		      
		      <td> <?php echo $row['play_ls'].", ".$row['play_fn'] ?> </td>
		      	  
		      	 <td>
		      	 </td>			    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		</table></p> 
	</div>
<?php endif ?>


<?php if (isset($_POST['viewSched'])): ?>

	<div class="w3-modal-content w3-animate-zoom blurwhite" id="printableArea"> 
        <a href="match.php" class="w3-button w3-display-topright w3-hover-dark-gray w3-black">
         &times;</a> 	  
		  <div class="w3-container w3-wide">
		    <h2> <?php echo $imgRhom ?> SCHEDULE </h2>
		    <h4 class="w3-center"> <?php echo $_POST['MatchName'] ?> SCHEDULE </h4>
		  </div>

    <p><table class="<?php echo $table ?>">
		  <tr class="<?php echo $trhead ?>">
		      <th>MATCH No. </th>
		      <th>DATE </th>
		      <th>TIME </th>
	      </tr>
	      <?php
	      	$ID = $_POST['viewSched'];
	      	$sql = "SELECT * FROM `tbl_schedules` WHERE `sched_id`='$ID'";
			$result = $conn->query($sql);
	      if ($result->num_rows > 0): ?>
	      		<?php while ($row = $result->fetch_assoc()): ?>
		    <tr class="<?php echo $tr ?>">
		       <td><?php echo $row['match_no'] ?></td>
		       <td><?php echo $row['sched_date'] ?></td>   
	      	   <td><?php echo $row['sched_time'] ?></td>	      		    	 
		    </tr>					      			
	      		<?php endwhile ?>		      	
	      <?php endif ?>

		 </table></p>  

    </div></p>

<?php endif ?>

